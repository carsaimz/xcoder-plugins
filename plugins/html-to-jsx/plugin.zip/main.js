(function () {
	"use strict";
	var xcoder = window.xcoder;
	if (!xcoder || typeof xcoder.setPluginInit !== "function") return;

	var PLUGIN_ID = "xcoder.html-to-jsx";

	/** Attribute renames applied to plain (non data-/aria-) attributes. */
	var ATTR_MAP = {
		"class": "className",
		"for": "htmlFor",
		"tabindex": "tabIndex",
		"readonly": "readOnly",
		"maxlength": "maxLength",
		"minlength": "minLength",
		"colspan": "colSpan",
		"rowspan": "rowSpan",
		"cellpadding": "cellPadding",
		"cellspacing": "cellSpacing",
		"autocomplete": "autoComplete",
		"autofocus": "autoFocus",
		"autoplay": "autoPlay",
		"contenteditable": "contentEditable",
		"contextmenu": "contextMenu",
		"crossorigin": "crossOrigin",
		"datetime": "dateTime",
		"enctype": "encType",
		"formaction": "formAction",
		"novalidate": "noValidate",
		"playsinline": "playsInline",
		"referrerpolicy": "referrerPolicy",
		"spellcheck": "spellCheck",
		"srcdoc": "srcDoc",
		"srcset": "srcSet",
		"usemap": "useMap",
		"accesskey": "accessKey",
		"allowfullscreen": "allowFullScreen",
		"inputmode": "inputMode",
		"list": "list",
		"maxlengthx": "maxLength",
	};

	var VOID_TAGS = ["area", "base", "br", "col", "embed", "hr", "img", "input", "link", "meta", "param", "source", "track", "wbr"];

	function camelCase(name) {
		return name.replace(/-([a-z])/g, function (_m, ch) {
			return ch.toUpperCase();
		});
	}

	function mapAttribute(name) {
		var lower = name.toLowerCase();
		if (lower.indexOf("data-") === 0 || lower.indexOf("aria-") === 0) return lower;
		if (lower.indexOf("on") === 0) return camelCase(lower);
		if (ATTR_MAP[lower]) return ATTR_MAP[lower];
		if (lower.indexOf("-") >= 0) return camelCase(lower);
		return lower;
	}

	/** style="color: red; font-size: 10px" → {{ color: "red", fontSize: "10px" }} */
	function convertStyle(value) {
		var parts = value.split(";").map(function (chunk) {
			return chunk.trim();
		}).filter(Boolean);
		var body = parts.map(function (chunk) {
			var idx = chunk.indexOf(":");
			if (idx < 0) return null;
			var prop = camelCase(chunk.slice(0, idx).trim());
			var val = chunk.slice(idx + 1).trim().replace(/"/g, '\\"');
			return prop + ': "' + val + '"';
		}).filter(Boolean).join(", ");
		return "{{ " + body + " }}";
	}

	var COMMENT_RE = /<!--([\s\S]*?)-->/g;
	var TAG_RE = /<(\/?)([a-zA-Z][a-zA-Z0-9-]*)((?:[^>"']|"[^"]*"|'[^']*')*)>/g;
	var ATTR_RE = /([a-zA-Z_][a-zA-Z0-9_:-]*)(?:\s*=\s*("([^"]*)"|'([^']*)'|[^\s"'=<>`]+))?/g;

	function convertHtmlToJsx(html) {
		var changes = 0;
		var output = html.replace(COMMENT_RE, function (_m, inner) {
			changes++;
			return "{/*" + inner + "*/}";
		});

		output = output.replace(TAG_RE, function (_m, closing, tagName, attrs) {
			var name = closing ? tagName : mapAttribute(tagName) === tagName ? tagName : tagName;
			var attrText = "";
			if (!closing && attrs && attrs.trim()) {
				attrText = attrs.replace(ATTR_RE, function (_a, attrName, _b, dq, sq) {
					var mapped = mapAttribute(attrName);
					var value = dq !== undefined ? dq : sq !== undefined ? sq : _b;
					if (value === undefined) {
						return " " + mapped;
					}
					if (mapped.toLowerCase() === "style") {
						changes++;
						return " style=" + convertStyle(value);
					}
					changes++;
					return " " + mapped + '="' + value + '"';
				});
			}
			var selfClose = "";
			if (!closing && VOID_TAGS.indexOf(tagName.toLowerCase()) >= 0) {
				selfClose = " /";
				changes++;
			}
			return "<" + closing + name + attrText + selfClose + ">";
		});

		return { text: output, changes: changes };
	}

	xcoder.setPluginInit(PLUGIN_ID, function () {
		var toast = xcoder.require("toast");

		xcoder.addCommand({
			name: "html-to-jsx:convert",
			description: "Convert HTML attributes, void tags and comments to JSX",
			bindKey: "Ctrl-Alt-X",
			readOnly: false,
			exec: function (view) {
				if (!view || !view.state) return false;
				var state = view.state;
				var selection = state.selection.main;
				var hasSelection = !!(selection && !selection.empty);
				var from = hasSelection ? selection.from : 0;
				var to = hasSelection ? selection.to : state.doc.length;
				var original = state.sliceDoc(from, to);
				if (!original) {
					toast("HTML to JSX: nothing to convert", 2500);
					return true;
				}
				var result = convertHtmlToJsx(original);
				if (result.changes === 0) {
					toast("HTML to JSX: already JSX-compatible", 2500);
					return true;
				}
				view.dispatch({
					changes: { from: from, to: to, insert: result.text },
					selection: { anchor: from, head: from + result.text.length },
				});
				toast("✓ converted (" + result.changes + " change(s))", 2200);
				return true;
			},
		});

		xcoder.setPluginUnmount(PLUGIN_ID, function () {
			xcoder.removeCommand("html-to-jsx:convert");
		});
	});
})();
