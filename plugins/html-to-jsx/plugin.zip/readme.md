# HTML to JSX

> Convert HTML to JSX: class→className, void tags self-close, comments become {/* */}.

**HTML to JSX** rewrites HTML so it compiles inside JSX/React: `class` becomes `className`, `for` becomes `htmlFor`, dozens of HTML attributes get their React names (`tabindex`→`tabIndex`, `maxlength`→`maxLength`…), `onclick` and friends become `onClick`, void tags turn into `<br />`, inline `style` attributes become object literals and comments become `{/* */}`.

## Usage
Select the HTML you want (or run on the whole document) and execute **HTML to JSX: convert** (`Ctrl-Alt-X`). The toast reports how many attributes were rewritten.

## Português
**HTML para JSX**: converte atributos HTML para os nomes do React (class→className, for→htmlFor…), fecha tags void, transforma style em objeto e comentários em `{/* */}`. Atalho `Ctrl-Alt-X`.

---

*Part of the [Xcoder plugin marketplace](https://github.com/carsaimz/xcoder-plugins). MIT licensed.*
