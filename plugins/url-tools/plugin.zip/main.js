(function () {
	"use strict";
	var xcoder = window.xcoder;
	if (!xcoder || typeof xcoder.setPluginInit !== "function") return;

	var PLUGIN_ID = "xcoder.url-tools";

	function toast(msg, ms) {
		xcoder.require("toast")(msg, ms || 3000);
	}

	function targetText(view) {
		var state = view.state;
		var range = state.selection.main;
		var has = !!(range && !range.empty);
		return {
			text: has ? state.sliceDoc(range.from, range.to) : state.doc.toString(),
			from: has ? range.from : 0,
			to: has ? range.to : state.doc.length,
		};
	}

	var ACTIONS = [
		{ value: "encodeComponent", text: "encodeURIComponent" },
		{ value: "decodeComponent", text: "decodeURIComponent" },
		{ value: "encodeURI", text: "encodeURI" },
		{ value: "decodeURI", text: "decodeURI" },
	];

	/** action id → native global function name */
	var ACTIONS_MAP = {
		encodeComponent: "encodeURIComponent",
		decodeComponent: "decodeURIComponent",
		encodeURI: "encodeURI",
		decodeURI: "decodeURI",
	};

	xcoder.setPluginInit(PLUGIN_ID, function () {
		var select = xcoder.require("select");

		xcoder.addCommand({
			name: "url-tools:run",
			description: "Encode/decode URLs (percent-encoding) on the selection or document",
			bindKey: "Ctrl-Alt-N",
			readOnly: false,
			exec: function (view) {
				if (!view || !view.state) return false;
				select("URL Tools", ACTIONS, {})
					.then(function (choice) {
						if (!choice) return null;
						var fn = globalThis[ACTIONS_MAP[choice]];
						if (typeof fn !== "function") {
							toast("Ação desconhecida: " + choice);
							return null;
						}
						var target = targetText(view);
						var out;
						try {
							out = fn(target.text);
						} catch (error) {
							toast("Falha: " + String(error.message || error).slice(0, 80), 4500);
							return null;
						}
						view.dispatch({
							changes: {
								from: target.from,
								to: target.to,
								insert: String(out),
							},
							scrollIntoView: true,
						});
						toast("✓ " + choice);
						return true;
					})
					.catch(function () { /* cancelled */ });
				return true;
			},
		});
	});

	xcoder.setPluginUnmount &&
		xcoder.setPluginUnmount(PLUGIN_ID, function () {});
})();
