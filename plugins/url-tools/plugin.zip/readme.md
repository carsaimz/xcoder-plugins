# URL Tools

> encodeURIComponent / decodeURIComponent (and URI variants) on the selection.

**URL Tools** encodes or decodes the current selection — or the whole document — with the four native browser functions: `encodeURIComponent`, `decodeURIComponent`, `encodeURI` and `decodeURI`. Perfect for building query strings, testing APIs and cleaning copy-pasted links with %20 everywhere.

## Usage
Select the text (or nothing for the whole file), run **URL tools** (`Ctrl-Alt-N`) and pick the operation. Invalid sequences show a friendly toast.

## Português
**Ferramentas de URL**: codifica/decodifica a seleção com encodeURIComponent, decodeURIComponent, encodeURI e decodeURI. Atalho `Ctrl-Alt-N`.

---

*Part of the [Xcoder plugin marketplace](https://github.com/carsaimz/xcoder-plugins). MIT licensed.*
