# Slugify

> Turn any text into an URL-friendly slug (kebab-case, accents stripped).

**Slugify** converts the selected text — or the word under the cursor — into a clean URL slug: lowercase, accents removed (NFD), spaces and punctuation collapsed into single hyphens. 'Bem-vindo ao Verão!' becomes `bem-vindo-ao-verao`. Ideal for blog routes, file names and ids.

## Usage
Select the text (or place the cursor on a word) and run **Slugify** (`Ctrl-Alt-L`). The result replaces the selection in place.

## Português
**Slugify**: converte o texto em slug URL-friendly — minúsculas, sem acentos, hífenes únicos. Atalho `Ctrl-Alt-L`.

---

*Part of the [Xcoder plugin marketplace](https://github.com/carsaimz/xcoder-plugins). MIT licensed.*
