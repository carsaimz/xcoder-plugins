(function () {
	"use strict";
	var xcoder = window.xcoder;
	if (!xcoder || typeof xcoder.setPluginInit !== "function") return;

	var PLUGIN_ID = "xcoder.slugify";

	function toast(msg, ms) {
		xcoder.require("toast")(msg, ms || 3000);
	}

	function slugify(text) {
		return String(text)
			.normalize("NFD")
			.replace(/[\u0300-\u036f]/g, "")
			.toLowerCase()
			.replace(/[^a-z0-9]+/g, "-")
			.replace(/^-+|-+$/g, "");
	}

	xcoder.setPluginInit(PLUGIN_ID, function () {
		xcoder.addCommand({
			name: "slugify:run",
			description: "Slugify the selection or word (URL-friendly kebab-case)",
			bindKey: "Ctrl-Alt-L",
			readOnly: false,
			exec: function (view) {
				if (!view || !view.state) return false;
				var state = view.state;
				var range = state.selection.main;
				var from = range.from;
				var to = range.to;
				if (range.empty) {
					var word = state.wordAt(range.head);
					if (!word) {
						toast("Selecione o texto para converter em slug");
						return true;
					}
					from = word.from;
					to = word.to;
				}
				var text = state.sliceDoc(from, to);
				var slug = slugify(text);
				if (!slug) {
					toast("Nada para converter");
					return true;
				}
				view.dispatch({
					changes: { from: from, to: to, insert: slug },
					scrollIntoView: true,
				});
				toast("✓ " + slug.slice(0, 40));
				return true;
			},
		});
	});

	xcoder.setPluginUnmount &&
		xcoder.setPluginUnmount(PLUGIN_ID, function () {});
})();
