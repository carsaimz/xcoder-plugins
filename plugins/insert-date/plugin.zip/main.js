(function () {
	"use strict";
	var xcoder = window.xcoder;
	if (!xcoder || typeof xcoder.setPluginInit !== "function") return;

	var PLUGIN_ID = "xcoder.insert-date";

	var OPTIONS = [
		["date", "Date (YYYY-MM-DD)"],
		["eu", "Date (DD/MM/YYYY)"],
		["us", "Date (MM/DD/YYYY)"],
		["time", "Time (HH:mm)"],
		["datetime", "Date & time (YYYY-MM-DD HH:mm)"],
		["timestamp", "Date & time with seconds"],
		["iso", "ISO 8601 (UTC)"],
		["locale", "Locale format"],
		["unix", "Unix timestamp (seconds)"],
	];

	function pad(value) {
		return String(value).length < 2 ? "0" + value : String(value);
	}

	function formatDate(value, choice) {
		var y = value.getFullYear();
		var m = pad(value.getMonth() + 1);
		var d = pad(value.getDate());
		var h = pad(value.getHours());
		var min = pad(value.getMinutes());
		var s = pad(value.getSeconds());
		switch (choice) {
			case "iso":
				return value.toISOString();
			case "eu":
				return d + "/" + m + "/" + y;
			case "us":
				return m + "/" + d + "/" + y;
			case "time":
				return h + ":" + min;
			case "datetime":
				return y + "-" + m + "-" + d + " " + h + ":" + min;
			case "timestamp":
				return y + "-" + m + "-" + d + " " + h + ":" + min + ":" + s;
			case "locale":
				return value.toLocaleString();
			case "unix":
				return String(Math.floor(value.getTime() / 1000));
			default:
				return y + "-" + m + "-" + d;
		}
	}

	xcoder.setPluginInit(PLUGIN_ID, function () {
		var select = xcoder.require("select");

		xcoder.addCommand({
			name: "insert-date:insert",
			description: "Insert current date and time",
			bindKey: "Ctrl-Alt-T",
			readOnly: false,
			exec: function (view) {
				if (!view || !view.state) return false;
				return select("Insert date & time", OPTIONS).then(function (choice) {
					if (!choice) return false;
					var text = formatDate(new Date(), choice);
					var selection = view.state.selection.main;
					var pos = selection ? selection.head : 0;
					view.dispatch({
						changes: { from: pos, insert: text },
						selection: { anchor: pos + text.length },
					});
					return true;
				});
			},
		});

		xcoder.setPluginUnmount(PLUGIN_ID, function () {
			xcoder.removeCommand("insert-date:insert");
		});
	});
})();
