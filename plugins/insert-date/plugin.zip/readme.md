# Insert Date & Time

> Insert the current date/time in nine formats at the cursor position.

**Insert Date & Time** places the current date and time exactly where the cursor is, in nine formats: `YYYY-MM-DD`, `DD/MM/YYYY`, `MM/DD/YYYY`, `HH:mm`, date + time, date + time with seconds, ISO 8601 (UTC), device locale format and Unix timestamp.

## Usage
Open the command palette and run **Insert date & time** (`Ctrl-Alt-T`), then choose a format. Useful for changelogs, commits notes, logs and journaling files.

## Português
**Inserir data e hora**: insere a data/hora atual na posição do cursor em nove formatos, incluindo ISO 8601 e timestamp Unix. Atalho `Ctrl-Alt-T`.

---

*Part of the [Xcoder plugin marketplace](https://github.com/carsaimz/xcoder-plugins). MIT licensed.*
