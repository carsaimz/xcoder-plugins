# Codex (XCoder)

Réplica funcional do fluxo do OpenAI Codex CLI adaptada ao XCoder.

## Comandos

| Comando | Atalho | O que faz |
| --- | --- | --- |
| Codex: generate AGENTS.md | Ctrl-Alt-8 | Escreve um `AGENTS.md` na raiz do projeto ativo |
| Codex: task from selection | Ctrl-Alt-7 | Seleção → tarefa estruturada |
| Codex: review prompt | Ctrl-Alt-6 | Prompt de revisão → clipboard |

Funciona offline; usa a área de transferência e o sistema de ficheiros do app.