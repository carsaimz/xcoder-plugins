# CSS Beautify

> Expand CSS to one declaration per line, or minify it back to a single line.

**CSS Beautify** formats stylesheets in both directions. *Beautify* expands every rule to one declaration per line with tab indentation and blank lines between rules; *Minify* strips comments and collapses all whitespace into a compact single line ready for production.

## Usage
Select some CSS (or run on the whole document) and execute **CSS beautify: run**, then pick the mode. Works on plain CSS as well as rules embedded in HTML.

## Português
**CSS Beautify**: formata CSS nos dois sentidos — *Beautify* expande uma declaração por linha com indentação, *Minify* remove comentários e espaços para produção.

---

*Part of the [Xcoder plugin marketplace](https://github.com/carsaimz/xcoder-plugins). MIT licensed.*
