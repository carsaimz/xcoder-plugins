(function () {
	"use strict";
	var xcoder = window.xcoder;
	if (!xcoder || typeof xcoder.setPluginInit !== "function") return;

	var PLUGIN_ID = "xcoder.css-beautify";

	function stripComments(css) {
		return css.replace(/\/\*[\s\S]*?\*\//g, "");
	}

	function minify(css) {
		return stripComments(css)
			.replace(/\s+/g, " ")
			.replace(/\s*([{}:;,>~+])\s*/g, "$1")
			.replace(/;}/g, "}")
			.trim();
	}

	function beautify(css) {
		var flat = minify(css);
		var indent = "";
		var output = [];
		var buffer = "";
		var inRule = false;

		for (var i = 0; i < flat.length; i++) {
			var ch = flat[i];
			if (ch === "{") {
				output.push(indent + buffer.trim() + " {");
				indent += "\t";
				buffer = "";
				inRule = true;
			} else if (ch === "}") {
				if (buffer.trim()) {
					output.push(indent + buffer.trim());
				}
				indent = indent.slice(1);
				output.push(indent + "}");
				output.push("");
				buffer = "";
				inRule = false;
			} else if (ch === ";" && inRule) {
				output.push(indent + buffer.trim() + ";");
				buffer = "";
			} else {
				buffer += ch;
			}
		}
		if (buffer.trim()) {
			output.push(indent + buffer.trim());
		}
		return output.join("\n").replace(/\n{3,}/g, "\n\n").trim() + "\n";
	}

	xcoder.setPluginInit(PLUGIN_ID, function () {
		var toast = xcoder.require("toast");
		var select = xcoder.require("select");

		xcoder.addCommand({
			name: "css-beautify:run",
			description: "Minify or expand CSS in the selection or document",
			readOnly: false,
			exec: function (view) {
				if (!view || !view.state) return false;
				var state = view.state;
				var selection = state.selection.main;
				var hasSelection = !!(selection && !selection.empty);
				var from = hasSelection ? selection.from : 0;
				var to = hasSelection ? selection.to : state.doc.length;
				var original = state.sliceDoc(from, to);
				if (!original) {
					toast("CSS beautify: nothing to format", 2500);
					return true;
				}
				return select("CSS beautify", [
					["beautify", "Beautify (expand, one declaration per line)"],
					["minify", "Minify (single line, no comments)"],
				])
					.then(function (choice) {
						if (!choice) return null;
						return choice === "minify" ? minify(original) : beautify(original);
					})
					.then(function (result) {
						if (result === null || result === original) {
							if (result !== null) toast("CSS beautify: nothing to change", 2000);
							return true;
						}
						view.dispatch({
							changes: { from: from, to: to, insert: result },
							selection: { anchor: from, head: from + result.length },
						});
						toast("✓ CSS formatted", 2000);
						return true;
					});
			},
		});

		xcoder.setPluginUnmount(PLUGIN_ID, function () {
			xcoder.removeCommand("css-beautify:run");
		});
	});
})();
