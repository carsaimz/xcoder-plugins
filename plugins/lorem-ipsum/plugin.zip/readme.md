# Lorem Ipsum

> Generate Lorem Ipsum placeholder paragraphs directly into the editor.

**Lorem Ipsum** generates classic placeholder text and inserts it at the cursor. Ask for any number of paragraphs (up to 50) and each one is freshly generated with varied sentence lengths, so mock-ups never look copy-pasted.

## Usage
Open the command palette and run **Lorem Ipsum: insert**. Type how many paragraphs you need (empty = 3) and confirm. Ideal for testing layouts, typography and page performance.

## Português
**Lorem Ipsum**: gera parágrafos de texto de preenchimento diretamente no editor — informe a quantidade (vazio = 3). Ideal para testar layouts e tipografia.

---

*Part of the [Xcoder plugin marketplace](https://github.com/carsaimz/xcoder-plugins). MIT licensed.*
