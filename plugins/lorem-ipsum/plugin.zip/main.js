(function () {
	"use strict";
	var xcoder = window.xcoder;
	if (!xcoder || typeof xcoder.setPluginInit !== "function") return;

	var PLUGIN_ID = "xcoder.lorem-ipsum";

	var WORDS = [
		"lorem", "ipsum", "dolor", "sit", "amet", "consectetur", "adipiscing",
		"elit", "sed", "do", "eiusmod", "tempor", "incididunt", "ut", "labore",
		"et", "dolore", "magna", "aliqua", "enim", "ad", "minim", "veniam",
		"quis", "nostrud", "exercitation", "ullamco", "laboris", "nisi",
		"aliquip", "ex", "ea", "commodo", "consequat", "duis", "aute", "irure",
		"in", "reprehenderit", "voluptate", "velit", "esse", "cillum", "fugiat",
		"nulla", "pariatur", "excepteur", "sint", "occaecat", "cupidatat",
		"non", "proident", "sunt", "culpa", "qui", "officia", "deserunt",
		"mollit", "anim", "id", "est", "laborum",
	];

	function pick() {
		return WORDS[Math.floor(Math.random() * WORDS.length)];
	}

	function sentence() {
		var length = 8 + Math.floor(Math.random() * 10);
		var parts = [];
		for (var i = 0; i < length; i++) parts.push(pick());
		var text = parts.join(" ");
		return text.charAt(0).toUpperCase() + text.slice(1) + ".";
	}

	function paragraph() {
		var count = 4 + Math.floor(Math.random() * 4);
		var parts = [];
		for (var i = 0; i < count; i++) parts.push(sentence());
		return parts.join(" ");
	}

	xcoder.setPluginInit(PLUGIN_ID, function () {
		var prompt = xcoder.require("prompt");

		xcoder.addCommand({
			name: "lorem-ipsum:insert",
			description: "Insert Lorem Ipsum placeholder text",
			readOnly: false,
			exec: function (view) {
				if (!view || !view.state) return false;
				return prompt("Lorem Ipsum", "Paragraphs (default 3)", "number").then(
					function (value) {
						var count = Number(value);
						var paragraphs =
							Number.isFinite(count) && count > 0 ? Math.min(count, 50) : 3;
						var text = [];
						for (var i = 0; i < paragraphs; i++) text.push(paragraph());
						var inserted = text.join("\n\n");
						var selection = view.state.selection.main;
						var pos = selection ? selection.head : 0;
						view.dispatch({
							changes: { from: pos, insert: inserted },
							selection: { anchor: pos + inserted.length },
						});
						return true;
					},
				);
			},
		});

		xcoder.setPluginUnmount(PLUGIN_ID, function () {
			xcoder.removeCommand("lorem-ipsum:insert");
		});
	});
})();
