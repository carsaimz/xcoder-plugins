(function () {
	"use strict";
	var xcoder = window.xcoder;
	if (!xcoder || typeof xcoder.setPluginInit !== "function") return;

	var PLUGIN_ID = "xcoder.trim-trailing";

	var OPTIONS = [
		["trim", "Trim trailing whitespace"],
		["trim-and-tabs", "Trim trailing whitespace + convert tabs to spaces (×4)"],
	];

	function trimText(text, convertTabs) {
		var lines = text.split(/\r?\n/);
		var changed = 0;
		for (var i = 0; i < lines.length; i++) {
			var line = lines[i];
			var cleaned = convertTabs ? line.replace(/\t/g, "    ") : line;
			cleaned = cleaned.replace(/[ \t]+$/, "");
			if (cleaned !== line) changed++;
			lines[i] = cleaned;
		}
		return { text: lines.join("\n"), changed: changed };
	}

	xcoder.setPluginInit(PLUGIN_ID, function () {
		var select = xcoder.require("select");
		var toast = xcoder.require("toast");

		xcoder.addCommand({
			name: "trim-trailing:run",
			description: "Remove trailing whitespace from every line (document or selection)",
			bindKey: "Ctrl-Alt-Z",
			readOnly: false,
			exec: function (view) {
				if (!view || !view.state) return false;
				var state = view.state;
				var selection = state.selection.main;
				var hasSelection = !!(selection && !selection.empty);
				var from = hasSelection ? selection.from : 0;
				var to = hasSelection ? selection.to : state.doc.length;
				var original = state.sliceDoc(from, to);
				if (!original) {
					toast("Trim trailing: nothing to clean", 2500);
					return true;
				}
				return select("Trim trailing whitespace", OPTIONS)
					.then(function (choice) {
						if (!choice) return null;
						return trimText(original, choice === "trim-and-tabs");
					})
					.then(function (result) {
						if (!result || result.text === original) {
							toast("Trim trailing: already clean", 2000);
							return true;
						}
						view.dispatch({
							changes: { from: from, to: to, insert: result.text },
							scrollIntoView: true,
						});
						toast("✓ " + result.changed + " linha(s) limpa(s)", 2200);
						return true;
					});
			},
		});

		xcoder.setPluginUnmount(PLUGIN_ID, function () {
			xcoder.removeCommand("trim-trailing:run");
		});
	});
})();
