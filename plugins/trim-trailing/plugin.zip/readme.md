# Trim Trailing

> Remove trailing whitespace from every line, optionally expanding tabs to spaces.

**Trim Trailing** strips trailing spaces and tabs from every line of the selection or document in one command, reporting how many lines were cleaned. The second mode also expands tabs to four spaces first — handy before saving files that must pass a whitespace linter.

## Usage
Run **Trim trailing** (`Ctrl-Alt-Z`) with or without a selection and pick the mode.

## Português
**Cortar espaços finais**: remove espaços/tabs do fim de cada linha (seleção ou documento) e expande tabs para espaços. Atalho `Ctrl-Alt-Z`.

---

*Part of the [Xcoder plugin marketplace](https://github.com/carsaimz/xcoder-plugins). MIT licensed.*
