(function () {
	"use strict";
	var xcoder = window.xcoder;
	if (!xcoder || typeof xcoder.setPluginInit !== "function") return;

	var PLUGIN_ID = "xcoder.markdown-toc";

	function toast(msg, ms) {
		xcoder.require("toast")(msg, ms || 3000);
	}

	/** GitHub-style anchor slug. */
	function slugify(text) {
		return String(text)
			.trim()
			.toLowerCase()
			.replace(/[^\p{L}\p{N}\-_ ]/gu, "")
			.replace(/\s+/g, "-");
	}

	/**
	 * Collects ATX headings (ignoring fenced code blocks).
	 * @returns {Array<{level: number, text: string, line: number}>}
	 */
	function collectHeadings(doc) {
		var headings = [];
		var inFence = false;
		for (var n = 1; n <= doc.lines; n++) {
			var line = doc.line(n).text;
			if (/^\s*(```|~~~)/.test(line)) {
				inFence = !inFence;
				continue;
			}
			if (inFence) continue;
			var match = /^(#{1,6})\s+(.+?)\s*#*\s*$/.exec(line);
			if (match) {
				headings.push({
					level: match[1].length,
					text: match[2].replace(/`/g, ""),
					line: n,
				});
			}
		}
		return headings;
	}

	function buildToc(headings) {
		if (!headings.length) return "";
		var min = Infinity;
		for (var i = 0; i < headings.length; i++) {
			min = Math.min(min, headings[i].level);
		}
		var lines = ["<!-- TOC -->"];
		var seen = {};
		for (var j = 0; j < headings.length; j++) {
			var h = headings[j];
			var indent = new Array(Math.max(0, h.level - min) * 2 + 1).join(" ");
			var slug = slugify(h.text);
			if (seen[slug] === undefined) {
				seen[slug] = 0;
			} else {
				seen[slug] += 1;
				slug += "-" + seen[slug];
			}
			lines.push(indent + "- [" + h.text + "](#" + slug + ")");
		}
		lines.push("<!-- /TOC -->");
		return lines.join("\n");
	}

	var BEGIN = "<!-- TOC -->";
	var END = "<!-- /TOC -->";

	function replaceExistingToc(view, toc) {
		var doc = view.state.doc;
		var beginLine = -1;
		var endLine = -1;
		for (var n = 1; n <= doc.lines; n++) {
			var text = doc.line(n).text.trim();
			if (text === BEGIN && beginLine === -1) beginLine = n;
			else if (text === END && beginLine !== -1) {
				endLine = n;
				break;
			}
		}
		if (beginLine === -1 || endLine === -1) return false;
		var from = doc.line(beginLine).from;
		var to = doc.line(endLine).to;
		view.dispatch({ changes: { from: from, to: to, insert: toc } });
		return true;
	}

	xcoder.setPluginInit(PLUGIN_ID, function () {
		xcoder.addCommand({
			name: "markdown-toc:generate",
			description: "Markdown: generate/refresh the table of contents",
			bindKey: "Ctrl-Alt-G",
			readOnly: false,
			exec: function (view) {
				if (!view || !view.state) return false;
				var headings = collectHeadings(view.state.doc);
				if (!headings.length) {
					toast("Nenhum título (# … ######) encontrado");
					return true;
				}
				var toc = buildToc(headings);
				if (replaceExistingToc(view, toc)) {
					toast("✓ Sumário atualizado (" + headings.length + " títulos)");
					return true;
				}
				// insert at the cursor (or right after a leading H1)
				var range = view.state.selection.main;
				var insertAt = range.from;
				var first = view.state.doc.line(1).text;
				if (/^#\s/.test(first) && view.state.doc.lines > 1) {
					insertAt = view.state.doc.line(2).from;
				}
				view.dispatch({
					changes: { from: insertAt, insert: toc + "\n\n" },
					selection: { anchor: insertAt + toc.length + 2 },
					scrollIntoView: true,
				});
				toast("✓ Sumário inserido (" + headings.length + " títulos)");
				return true;
			},
		});

		xcoder.setPluginUnmount(PLUGIN_ID, function () {
			xcoder.removeCommand("markdown-toc:generate");
		});
	});
})();
