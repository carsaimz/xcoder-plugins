# Markdown TOC

> Generate or refresh a GitHub-style table of contents from your Markdown headings.

**Markdown TOC** scans the document for `#`…`######` headings (skipping fenced code blocks) and builds a GitHub-style table of contents with correct anchor slugs — including duplicate heading disambiguation. If a `<!-- TOC -->` block already exists it is refreshed in place; otherwise the TOC is inserted right after the first H1.

## Usage
Open a Markdown file, run **Markdown: generate TOC** (`Ctrl-Alt-G`). Re-run any time after editing — the markers `<!-- TOC -->` / `<!-- /TOC -->` keep the section updated.

## Português
**Sumário Markdown**: gera/atualiza um sumário no estilo GitHub a partir dos títulos (ignorando blocos de código), com âncoras corretas. Atalho `Ctrl-Alt-G`.

---

*Part of the [Xcoder plugin marketplace](https://github.com/carsaimz/xcoder-plugins). MIT licensed.*
