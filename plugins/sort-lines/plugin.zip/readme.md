# Sort Lines

> Sort, reverse, shuffle or deduplicate the selected lines (or the whole document).

**Sort Lines** organises the selected lines — or the whole document when nothing is selected — with seven modes: ascending, descending, case-insensitive, numeric aware, unique (removes duplicated lines), reverse and shuffle.

## Usage
Select the lines you want to organise, open the command palette and run **Sort lines** (`Ctrl-Alt-S`). Perfect for lists, imports blocks, CSS properties and cleanup of duplicated data.

## Português
**Ordenar linhas**: organiza as linhas selecionadas (ou o documento inteiro) em sete modos — A-Z, Z-A, ignorar maiúsculas, numérico, único (remove duplicadas), inverter e aleatório. Atalho `Ctrl-Alt-S`.

---

*Part of the [Xcoder plugin marketplace](https://github.com/carsaimz/xcoder-plugins). MIT licensed.*
