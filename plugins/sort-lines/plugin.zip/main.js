(function () {
	"use strict";
	var xcoder = window.xcoder;
	if (!xcoder || typeof xcoder.setPluginInit !== "function") return;

	var PLUGIN_ID = "xcoder.sort-lines";

	var OPTIONS = [
		["asc", "Ascending (A-Z)"],
		["desc", "Descending (Z-A)"],
		["insensitive", "Case-insensitive (A-Z)"],
		["numeric", "Numeric (1, 2, 10...)"],
		["unique", "Unique (remove duplicates)"],
		["reverse", "Reverse order"],
		["shuffle", "Shuffle"],
	];

	function sortLines(lines, choice) {
		var sorted = lines.slice();
		switch (choice) {
			case "asc":
				sorted.sort(function (a, b) {
					return a.localeCompare(b);
				});
				break;
			case "desc":
				sorted.sort(function (a, b) {
					return b.localeCompare(a);
				});
				break;
			case "insensitive":
				sorted.sort(function (a, b) {
					return a.toLowerCase().localeCompare(b.toLowerCase());
				});
				break;
			case "numeric":
				sorted.sort(function (a, b) {
					var na = parseFloat(a.replace(/^[^\d-]*/, ""));
					var nb = parseFloat(b.replace(/^[^\d-]*/, ""));
					if (Number.isNaN(na) && Number.isNaN(nb)) return a.localeCompare(b);
					if (Number.isNaN(na)) return 1;
					if (Number.isNaN(nb)) return -1;
					return na - nb;
				});
				break;
			case "unique": {
				var seen = Object.create(null);
				sorted = sorted.filter(function (line) {
					var key = line.trim();
					if (seen[key]) return false;
					seen[key] = true;
					return true;
				});
				break;
			}
			case "reverse":
				sorted.reverse();
				break;
			case "shuffle":
				for (var i = sorted.length - 1; i > 0; i--) {
					var j = Math.floor(Math.random() * (i + 1));
					var tmp = sorted[i];
					sorted[i] = sorted[j];
					sorted[j] = tmp;
				}
				break;
		}
		return sorted;
	}

	xcoder.setPluginInit(PLUGIN_ID, function () {
		var select = xcoder.require("select");
		var toast = xcoder.require("toast");

		xcoder.addCommand({
			name: "sort-lines:sort",
			description: "Sort lines of selection or document",
			bindKey: "Ctrl-Alt-S",
			readOnly: false,
			exec: function (view) {
				if (!view || !view.state) return false;
				var state = view.state;
				var selection = state.selection.main;
				var hasSelection = !!(selection && !selection.empty);
				var firstLine = state.doc.lineAt(hasSelection ? selection.from : 0);
				var lastLine = state.doc.lineAt(
					hasSelection ? selection.to : state.doc.length,
				);
				var from = firstLine.from;
				var to = lastLine.to;
				var lines = state.sliceDoc(from, to).split("\n");
				if (lines.length < 2) {
					toast("Sort lines: select at least two lines", 2500);
					return false;
				}
				return select("Sort lines", OPTIONS).then(function (choice) {
					if (!choice) return false;
					var sorted = sortLines(lines, choice);
					if (sorted.join("\n") === lines.join("\n")) return true;
					view.dispatch({ changes: { from: from, to: to, insert: sorted.join("\n") } });
					return true;
				});
			},
		});

		xcoder.setPluginUnmount(PLUGIN_ID, function () {
			xcoder.removeCommand("sort-lines:sort");
		});
	});
})();
