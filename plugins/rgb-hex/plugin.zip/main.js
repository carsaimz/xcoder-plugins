(function () {
	"use strict";
	var xcoder = window.xcoder;
	if (!xcoder || typeof xcoder.setPluginInit !== "function") return;

	var PLUGIN_ID = "xcoder.rgb-hex";

	var OPTIONS = [
		["hex-to-rgb", "Hex → rgb() / rgba()"],
		["rgb-to-hex", "rgb()/rgba() → Hex"],
	];

	function clamp255(value) {
		return Math.max(0, Math.min(255, Math.round(value)));
	}

	/** Parses #rgb, #rgba, #rrggbb and #rrggbbaa into {r,g,b,a}. */
	function parseHex(input) {
		var value = input.trim().replace(/^#/, "");
		if (/^[0-9a-fA-F]{3}$/.test(value)) {
			return {
				r: parseInt(value[0] + value[0], 16),
				g: parseInt(value[1] + value[1], 16),
				b: parseInt(value[2] + value[2], 16),
				a: 1,
			};
		}
		if (/^[0-9a-fA-F]{4}$/.test(value)) {
			return {
				r: parseInt(value[0] + value[0], 16),
				g: parseInt(value[1] + value[1], 16),
				b: parseInt(value[2] + value[2], 16),
				a: parseInt(value[3] + value[3], 16) / 255,
			};
		}
		if (/^[0-9a-fA-F]{6}$/.test(value)) {
			return {
				r: parseInt(value.slice(0, 2), 16),
				g: parseInt(value.slice(2, 4), 16),
				b: parseInt(value.slice(4, 6), 16),
				a: 1,
			};
		}
		if (/^[0-9a-fA-F]{8}$/.test(value)) {
			return {
				r: parseInt(value.slice(0, 2), 16),
				g: parseInt(value.slice(2, 4), 16),
				b: parseInt(value.slice(4, 6), 16),
				a: parseInt(value.slice(6, 8), 16) / 255,
			};
		}
		return null;
	}

	function toHexChannel(number) {
		var clamped = clamp255(number);
		return clamped.toString(16).padStart(2, "0");
	}

	/** Parses rgb()/rgba() into {r,g,b,a}. */
	function parseRgb(input) {
		var match = input.match(/^rgba?\(\s*([\d.]+)\s*[, ]\s*([\d.]+)\s*[, ]\s*([\d.]+)\s*(?:[,/]\s*([\d.]+%?)\s*)?\)$/i);
		if (!match) return null;
		var alpha = 1;
		if (match[4] !== undefined) {
			alpha = match[4].indexOf("%") >= 0
				? parseFloat(match[4]) / 100
				: parseFloat(match[4]);
		}
		return {
			r: clamp255(parseFloat(match[1])),
			g: clamp255(parseFloat(match[2])),
			b: clamp255(parseFloat(match[3])),
			a: Math.max(0, Math.min(1, alpha)),
		};
	}

	function rgbToHex(color) {
		var hex = "#" + toHexChannel(color.r) + toHexChannel(color.g) + toHexChannel(color.b);
		if (color.a < 1) hex += toHexChannel(Math.round(color.a * 255));
		return hex.toLowerCase();
	}

	function rgbToCss(color) {
		var base = clamp255(color.r) + ", " + clamp255(color.g) + ", " + clamp255(color.b);
		if (color.a < 1) return "rgba(" + base + ", " + (Math.round(color.a * 100) / 100) + ")";
		return "rgb(" + base + ")";
	}

	/** Converts every color token found in the text. */
	function convertAll(text, mode) {
		var changed = false;
		var result = text.replace(/#[0-9a-fA-F]{3,8}\b|rgba?\(\s*[\d.]+\s*[, ]\s*[\d.]+\s*[, ]\s*[\d.]+\s*(?:[,/]\s*[\d.%]+\s*)?\)/gi, function (token) {
			var color = mode === "hex-to-rgb" ? parseHex(token) : parseRgb(token);
			if (!color) return token;
			changed = true;
			return mode === "hex-to-rgb" ? rgbToCss(color) : rgbToHex(color);
		});
		return changed ? result : null;
	}

	xcoder.setPluginInit(PLUGIN_ID, function () {
		var select = xcoder.require("select");
		var toast = xcoder.require("toast");

		xcoder.addCommand({
			name: "rgb-hex:convert",
			description: "Convert colors between hex and rgb() in the selection",
			bindKey: "Ctrl-Alt-Y",
			readOnly: false,
			exec: function (view) {
				if (!view || !view.state) return false;
				var state = view.state;
				var range = state.selection.main;
				var from = range.from;
				var to = range.to;
				if (range.empty) {
					var word = state.wordAt(range.head);
					if (!word) {
						toast("RGB ↔ Hex: select a color first", 2500);
						return true;
					}
					from = word.from;
					to = word.to;
				}
				var original = state.sliceDoc(from, to);
				return select("RGB ↔ Hex", OPTIONS)
					.then(function (choice) {
						if (!choice) return null;
						var result = convertAll(original, choice);
						if (result === null) toast("RGB ↔ Hex: no convertible colors found", 2500);
						return result;
					})
					.then(function (result) {
						if (result === null) return true;
						view.dispatch({
							changes: { from: from, to: to, insert: result },
							selection: { anchor: from, head: from + result.length },
						});
						toast("✓ converted", 2000);
						return true;
					});
			},
		});

		xcoder.setPluginUnmount(PLUGIN_ID, function () {
			xcoder.removeCommand("rgb-hex:convert");
		});
	});
})();
