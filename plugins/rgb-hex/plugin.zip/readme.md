# RGB ↔ Hex Converter

> Convert every color in the selection between hex and rgb()/rgba(), alpha included.

**RGB ↔ Hex Converter** finds every color token in the selection — short/long hex, with or without alpha, and `rgb()`/`rgba()` with comma or slash alpha — and converts all of them in one pass. Alpha values are kept as-is, so `#7c3aed80` becomes `rgba(124, 58, 237, 0.5)` and back.

## Usage
Select the colors (or place the cursor on one), run **RGB ↔ Hex** (`Ctrl-Alt-Y`) and pick the direction.

## Português
**Conversor RGB ↔ Hex**: converte todas as cores da seleção entre hex e rgb()/rgba(), mantendo o canal alfa. Atalho `Ctrl-Alt-Y`.

---

*Part of the [Xcoder plugin marketplace](https://github.com/carsaimz/xcoder-plugins). MIT licensed.*
