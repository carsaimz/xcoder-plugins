(function () {
	"use strict";
	var xcoder = window.xcoder;
	if (!xcoder || typeof xcoder.setPluginInit !== "function") return;

	var PLUGIN_ID = "xcoder.html-entities";

	var ENCODE = {
		"&": "&amp;",
		"<": "&lt;",
		">": "&gt;",
		'"': "&quot;",
		"'": "&#39;",
	};

	var DECODE = {
		"&amp;": "&",
		"&lt;": "<",
		"&gt;": ">",
		"&quot;": '"',
		"&#39;": "'",
		"&apos;": "'",
		"&nbsp;": " ",
	};

	var OPTIONS = [
		["encode", "Encode entities (& < > \" ')"],
		["decode", "Decode named + numeric entities"],
	];

	function encodeEntities(text) {
		return text.replace(/[&<>"']/g, function (char) {
			return ENCODE[char];
		});
	}

	function decodeEntities(text) {
		return text
			.replace(/&#x([0-9a-fA-F]+);/g, function (_m, hex) {
				return String.fromCodePoint(parseInt(hex, 16));
			})
			.replace(/&#(\d+);/g, function (_m, dec) {
				return String.fromCodePoint(parseInt(dec, 10));
			})
			.replace(/&(amp|lt|gt|quot|#39|apos|nbsp);/g, function (_m, name) {
				return DECODE["&" + name + ";"];
			});
	}

	xcoder.setPluginInit(PLUGIN_ID, function () {
		var select = xcoder.require("select");
		var toast = xcoder.require("toast");

		xcoder.addCommand({
			name: "html-entities:convert",
			description: "Encode or decode HTML entities in the selection",
			bindKey: "Ctrl-Alt-M",
			readOnly: false,
			exec: function (view) {
				if (!view || !view.state) return false;
				var state = view.state;
				var range = state.selection.main;
				var from = range.from;
				var to = range.to;
				if (range.empty) {
					var word = state.wordAt(range.head);
					if (!word) {
						toast("HTML entities: select some text first", 2500);
						return true;
					}
					from = word.from;
					to = word.to;
				}
				var original = state.sliceDoc(from, to);
				return select("HTML entities", OPTIONS)
					.then(function (choice) {
						if (!choice) return null;
						return choice === "encode" ? encodeEntities(original) : decodeEntities(original);
					})
					.then(function (result) {
						if (result === null || result === original) return true;
						view.dispatch({
							changes: { from: from, to: to, insert: result },
							selection: { anchor: from, head: from + result.length },
						});
						toast("✓ converted", 2000);
						return true;
					});
			},
		});

		xcoder.setPluginUnmount(PLUGIN_ID, function () {
			xcoder.removeCommand("html-entities:convert");
		});
	});
})();
