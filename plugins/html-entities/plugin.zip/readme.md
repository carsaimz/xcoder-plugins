# HTML Entities

> Encode/decode HTML entities (&, <, >, quotes) including numeric references.

**HTML Entities** escapes the five markup-critical characters (`&`, `<`, `>`, `"`, `'`) to their named entities and decodes them back — including numeric references (`&#39;`, `&#x27;`) and `&nbsp;`. Essential when embedding code samples in HTML or cleaning generated markup.

## Usage
Select the text (or place the cursor on a word), run **HTML entities** (`Ctrl-Alt-M`) and choose encode or decode.

## Português
**Entidades HTML**: codifica/decodifica &, <, >, aspas e referências numéricas na seleção. Atalho `Ctrl-Alt-M`.

---

*Part of the [Xcoder plugin marketplace](https://github.com/carsaimz/xcoder-plugins). MIT licensed.*
