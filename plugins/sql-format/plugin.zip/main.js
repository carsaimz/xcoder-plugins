(function () {
	"use strict";
	var xcoder = window.xcoder;
	if (!xcoder || typeof xcoder.setPluginInit !== "function") return;

	var PLUGIN_ID = "xcoder.sql-format";

	var MAJOR_KEYWORDS = [
		"FROM", "WHERE", "GROUP BY", "HAVING", "ORDER BY", "LIMIT", "OFFSET",
		"VALUES", "SET", "UNION ALL", "UNION", "RETURNING",
	];

	var JOIN_KEYWORDS = [
		"INNER JOIN", "LEFT OUTER JOIN", "RIGHT OUTER JOIN", "FULL OUTER JOIN",
		"LEFT JOIN", "RIGHT JOIN", "FULL JOIN", "CROSS JOIN", "JOIN",
	];

	var ALL_KEYWORDS = MAJOR_KEYWORDS.concat(JOIN_KEYWORDS, [
		"SELECT", "INSERT INTO", "UPDATE", "DELETE FROM", "AND", "OR", "NOT",
		"NULL", "IS NULL", "IS NOT NULL", "IN", "LIKE", "BETWEEN", "AS",
		"DISTINCT", "COUNT", "SUM", "AVG", "MIN", "MAX", "ON", "ASC", "DESC",
		"EXISTS", "CASE", "WHEN", "THEN", "ELSE", "END",
	]);

	/** Splits SQL into string-literal and code chunks so keywords inside
	 * quotes are never touched. */
	function splitLiterals(sql) {
		return sql.split(/('(?:[^']|'')*')/g);
	}

	function uppercaseKeywords(code) {
		var sorted = ALL_KEYWORDS.slice().sort(function (a, b) {
			return b.length - a.length;
		});
		var pattern = new RegExp("\\b(" + sorted.map(escapeRegex).join("|") + ")\\b", "gi");
		return code.replace(pattern, function (word) {
			return word.toUpperCase();
		});
	}

	function escapeRegex(text) {
		return text.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
	}

	function breakLines(sql) {
		var sorted = MAJOR_KEYWORDS.concat(JOIN_KEYWORDS).sort(function (a, b) {
			return b.length - a.length;
		});
		var pattern = new RegExp("(\\b(?:" + sorted.map(escapeRegex).join("|") + ")\\b)", "gi");
		return sql
			.replace(pattern, "\n$1")
			.replace(/\n[ \t]+/g, "\n")
			.replace(/\n{2,}/g, "\n")
			.trim();
	}

	function formatSql(sql) {
		var chunks = splitLiterals(sql.replace(/\s+/g, " "));
		for (var i = 0; i < chunks.length; i += 2) {
			chunks[i] = uppercaseKeywords(chunks[i]);
		}
		var joined = chunks.join("");
		var broken = splitLiterals(joined);
		for (var j = 0; j < broken.length; j += 2) {
			broken[j] = breakLines(broken[j]);
		}
		return broken.join("").replace(/[ \t]+\n/g, "\n").trim() + ";";
	}

	xcoder.setPluginInit(PLUGIN_ID, function () {
		var toast = xcoder.require("toast");

		xcoder.addCommand({
			name: "sql-format:format",
			description: "Format SQL: uppercase keywords and break major clauses",
			readOnly: false,
			exec: function (view) {
				if (!view || !view.state) return false;
				var state = view.state;
				var selection = state.selection.main;
				var hasSelection = !!(selection && !selection.empty);
				var from = hasSelection ? selection.from : 0;
				var to = hasSelection ? selection.to : state.doc.length;
				var original = state.sliceDoc(from, to);
				if (!original) {
					toast("SQL format: nothing to format", 2500);
					return true;
				}
				var formatted = formatSql(original);
				if (formatted === original) {
					toast("SQL format: nothing to change", 2000);
					return true;
				}
				view.dispatch({
					changes: { from: from, to: to, insert: formatted },
					selection: { anchor: from, head: from + formatted.length },
				});
				toast("✓ SQL formatted", 2000);
				return true;
			},
		});

		xcoder.setPluginUnmount(PLUGIN_ID, function () {
			xcoder.removeCommand("sql-format:format");
		});
	});
})();
