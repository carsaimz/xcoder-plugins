# SQL Format

> Format SQL queries: uppercase keywords, one major clause per line.

**SQL Format** normalizes SQL queries: keywords are uppercased (`SELECT`, `FROM`, `LEFT JOIN`…), major clauses start on their own line and trailing whitespace is cleaned. String literals are preserved untouched — keywords inside quotes are never modified.

## Usage
Select a query (or run on the whole document) and execute **SQL format: format**. Handy before committing queries or sharing them in documentation.

## Português
**SQL Format**: formata consultas SQL — palavras-chave em maiúsculas, cláusulas principais em linhas próprias, literais de string preservados.

---

*Part of the [Xcoder plugin marketplace](https://github.com/carsaimz/xcoder-plugins). MIT licensed.*
