(function () {
	"use strict";
	var xcoder = window.xcoder;
	if (!xcoder || typeof xcoder.setPluginInit !== "function") return;

	var PLUGIN_ID = "xcoder.json-tools";

	function toast(msg, ms) {
		xcoder.require("toast")(msg, ms || 3000);
	}

	/** JSON of the selection, or the whole document. */
	function targetText(view) {
		var state = view.state;
		var range = state.selection.main;
		var has = !!(range && !range.empty);
		return {
			text: has ? state.sliceDoc(range.from, range.to) : state.doc.toString(),
			from: has ? range.from : 0,
			to: has ? range.to : state.doc.length,
			scoped: has,
		};
	}

	function replace(view, target, text) {
		view.dispatch({
			changes: { from: target.from, to: target.to, insert: text },
			scrollIntoView: true,
		});
	}

	function parseOrThrow(text) {
		try {
			return { value: JSON.parse(text) };
		} catch (error) {
			var message = String(error.message || error);
			var pos = /position (\d+)/.exec(message);
			var hint = pos ? " (position " + pos[1] + ")" : "";
			throw new Error("JSON inválido" + hint + ": " + message.slice(0, 120));
		}
	}

	var ACTIONS = [
		{ value: "pretty2", text: "Pretty print (2 spaces)" },
		{ value: "pretty4", text: "Pretty print (4 spaces)" },
		{ value: "minify", text: "Minify" },
		{ value: "escape", text: "Escape (JSON string)" },
		{ value: "unescape", text: "Unescape" },
	];

	xcoder.setPluginInit(PLUGIN_ID, function () {
		var select = xcoder.require("select");

		xcoder.addCommand({
			name: "json-tools:run",
			description: "JSON tools: pretty print, minify, escape or validate",
			bindKey: "Ctrl-Alt-J",
			readOnly: false,
			exec: function (view) {
				if (!view || !view.state) return false;
				select("JSON Tools", ACTIONS, {})
					.then(function (choice) {
						if (!choice) return false;
						var target = targetText(view);
						if (choice === "escape") {
							replace(view, target, JSON.stringify(target.text));
							return true;
						}
						if (choice === "unescape") {
							try {
								var un = JSON.parse(target.text);
								replace(view, target, typeof un === "string" ? un : JSON.stringify(un, null, 2));
							} catch (e) {
								toast("Não é uma string JSON escapada");
							}
							return true;
						}
						try {
							var parsed = parseOrThrow(target.text);
							if (choice === "minify") {
								replace(view, target, JSON.stringify(parsed.value));
							} else {
								replace(
									view,
									target,
									JSON.stringify(parsed.value, null, choice === "pretty4" ? 4 : 2),
								);
							}
							toast("✓ JSON válido");
						} catch (error) {
							// invalid JSON — show the friendly message instead of
							// letting it vanish into the rejected promise
							toast(String(error.message || error), 4500);
						}
						return true;
					})
					.catch(function () { /* dialog cancelled */ });
				return true;
			},
		});

		xcoder.addCommand({
			name: "json-tools:validate",
			description: "Validate JSON (selection or document)",
			bindKey: "",
			readOnly: true,
			exec: function (view) {
				if (!view || !view.state) return false;
				var target = targetText(view);
				try {
					JSON.parse(target.text);
					toast("✓ JSON válido — " + (target.scoped ? "seleção" : "documento"));
				} catch (error) {
					toast(String(error.message || error).slice(0, 160), 4500);
				}
				return true;
			},
		});

		xcoder.setPluginUnmount(PLUGIN_ID, function () {
			xcoder.removeCommand("json-tools:run");
			xcoder.removeCommand("json-tools:validate");
		});
	});
})();
