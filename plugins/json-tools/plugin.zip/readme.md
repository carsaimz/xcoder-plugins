# JSON Tools

> Pretty print, minify, escape, unescape and validate JSON with friendly errors.

**JSON Tools** turns messy JSON into readable form in one tap: pretty print with 2 or 4 spaces, minify, escape a text into a JSON string, unescape it back, and a dedicated validator. Syntax errors report the approximate position so you can fix broken payloads quickly. Works on the selection or the whole document.

## Usage
Select the JSON (or leave the whole document), open the command palette and run **JSON tools** (`Ctrl-Alt-J`) — then pick the action. **JSON: validate** (`json-tools:validate`) only checks and reports.

## Português
**Ferramentas JSON**: formata (2/4 espaços), minifica, escapa, desescapa e valida JSON da seleção ou do documento, com erros que apontam a posição. Atalho `Ctrl-Alt-J`.

---

*Part of the [Xcoder plugin marketplace](https://github.com/carsaimz/xcoder-plugins). MIT licensed.*
