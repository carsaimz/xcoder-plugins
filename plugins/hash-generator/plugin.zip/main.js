(function () {
	"use strict";
	var xcoder = window.xcoder;
	if (!xcoder || typeof xcoder.setPluginInit !== "function") return;

	var PLUGIN_ID = "xcoder.hash-generator";

	function toast(msg, ms) {
		xcoder.require("toast")(msg, ms || 3000);
	}

	async function sha(algorithm, text) {
		var bytes = new TextEncoder().encode(text);
		var digest = await crypto.subtle.digest(algorithm, bytes);
		var array = new Uint8Array(digest);
		var hex = "";
		for (var i = 0; i < array.length; i++) {
			hex += (array[i] + 0x100).toString(16).slice(1);
		}
		return hex;
	}

	function base64OfHex(hex) {
		var bytes = new Uint8Array(hex.length / 2);
		for (var i = 0; i < bytes.length; i++) {
			bytes[i] = parseInt(hex.slice(i * 2, i * 2 + 2), 16);
		}
		var binary = "";
		for (var j = 0; j < bytes.length; j++) binary += String.fromCharCode(bytes[j]);
		return btoa(binary);
	}

	xcoder.setPluginInit(PLUGIN_ID, function () {
		var select = xcoder.require("select");

		xcoder.addCommand({
			name: "hash-generator:run",
			description: "Hash the selection or document (SHA-1/256/384/512)",
			bindKey: "Ctrl-Alt-K",
			readOnly: true,
			exec: function (view) {
				if (!view || !view.state) return false;
				var state = view.state;
				var range = state.selection.main;
				var scoped = !!(range && !range.empty);
				var text = scoped
					? state.sliceDoc(range.from, range.to)
					: state.doc.toString();

				select(
					"Hash Generator — " + (scoped ? "seleção" : "documento"),
					[
						{ value: "SHA-256", text: "SHA-256 (recomendado)" },
						{ value: "SHA-512", text: "SHA-512" },
						{ value: "SHA-384", text: "SHA-384" },
						{ value: "SHA-1", text: "SHA-1 (legado)" },
					],
					{},
				)
					.then(function (algorithm) {
						if (!algorithm) return false;
						return sha(algorithm, text).then(function (hex) {
							return select(
								algorithm + " — " + hex.slice(0, 16) + "…",
								[
									{ value: "copy", text: "📋 Copiar hash (hex)" },
									{ value: "copy64", text: "📋 Copiar hash (Base64)" },
									{ value: "insert", text: "⬇️ Inserir no cursor" },
									{ value: "wrap", text: "⬇️ Inserir como comentário" },
								],
								{},
							).then(function (action) {
								if (!action) return false;
								if (action === "copy" || action === "copy64") {
									var value = action === "copy" ? hex : base64OfHex(hex);
									if (navigator.clipboard) {
										navigator.clipboard.writeText(value);
										toast("✓ Hash copiado");
									} else {
										toast(value, 6000);
									}
								} else if (action === "insert") {
									view.dispatch({
										changes: { from: range.to, insert: "\n" + hex },
										selection: { anchor: range.to + 1 + hex.length },
										scrollIntoView: true,
									});
								} else if (action === "wrap") {
									var comment = "// sha256: " + hex + "\n";
									view.dispatch({
										changes: { from: range.to, insert: "\n" + comment },
										selection: { anchor: range.to + 1 + comment.length },
										scrollIntoView: true,
									});
								}
							});
						});
					})
					.catch(function () { /* cancelled */ });
				return true;
			},
		});

		xcoder.setPluginUnmount(PLUGIN_ID, function () {
			xcoder.removeCommand("hash-generator:run");
		});
	});
})();
