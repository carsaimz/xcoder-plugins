# Hash Generator

> Hash the selection or document with SHA-1/256/384/512 and copy or insert the digest.

**Hash Generator** computes SHA digests with the platform's Web Crypto (fast and offline): SHA-256, SHA-512, SHA-384 and legacy SHA-1. Copy the digest as hex or Base64, insert it at the cursor, or drop it as a `// sha256: …` comment next to the selection. Ideal for verifying payloads, caching keys and committing integrity checks.

## Usage
Select the text to hash (or hash the whole document), open the command palette and run **Hash generator** (`Ctrl-Alt-K`), pick the algorithm and the output action.

## Português
**Gerador de hash**: calcula SHA-256/512/384/SHA-1 da seleção ou do documento com Web Crypto (offline) e copia (hex/Base64) ou insere o resultado. Atalho `Ctrl-Alt-K`.

---

*Part of the [Xcoder plugin marketplace](https://github.com/carsaimz/xcoder-plugins). MIT licensed.*
