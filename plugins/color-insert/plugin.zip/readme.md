# Color Insert

> Pick a color from a palette or paste a hex and insert it as HEX, RGB or HSL.

**Color Insert** speeds up styling work: choose a color from a curated 24-tone palette (or type any hex) and insert it in HEX, `rgb()` or `hsl()` notation — the conversions happen for you. Great for CSS, Compose, SVG and design tokens.

## Usage
Open the command palette and run **Color picker** (`Ctrl-Alt-H`), pick a color, choose the notation. 3-digit hex shorthands are accepted and normalized.

## Português
**Inserir cor**: escolha uma cor da paleta ou digite um hex e insira como HEX, `rgb()` ou `hsl()` — a conversão é automática. Atalho `Ctrl-Alt-H`.

---

*Part of the [Xcoder plugin marketplace](https://github.com/carsaimz/xcoder-plugins). MIT licensed.*
