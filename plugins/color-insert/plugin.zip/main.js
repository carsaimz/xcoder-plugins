(function () {
	"use strict";
	var xcoder = window.xcoder;
	if (!xcoder || typeof xcoder.setPluginInit !== "function") return;

	var PLUGIN_ID = "xcoder.color-insert";

	/** A tasteful palette: material + xcoder-ish tones. */
	var PALETTE = [
		"#7B61FF", "#9A6BFC", "#4B7EF8", "#2196F3", "#03A9F4", "#00BCD4",
		"#009688", "#4CAF50", "#8BC34A", "#CDDC39", "#FFC107", "#FF9800",
		"#FF5722", "#F44336", "#E91E63", "#9C27B0", "#673AB7", "#3F51B5",
		"#212121", "#424242", "#616161", "#9E9E9E", "#BDBDBD", "#FFFFFF",
	];

	function hexToRgb(hex) {
		var value = hex.replace("#", "");
		if (value.length === 3) {
			value = value[0] + value[0] + value[1] + value[1] + value[2] + value[2];
		}
		var num = parseInt(value, 16);
		if (Number.isNaN(num) || value.length !== 6) return null;
		return {
			r: (num >> 16) & 255,
			g: (num >> 8) & 255,
			b: num & 255,
		};
	}

	function rgbToHsl(r, g, b) {
		r /= 255; g /= 255; b /= 255;
		var max = Math.max(r, g, b);
		var min = Math.min(r, g, b);
		var h = 0;
		var s = 0;
		var l = (max + min) / 2;
		if (max !== min) {
			var d = max - min;
			s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
			if (max === r) h = (g - b) / d + (g < b ? 6 : 0);
			else if (max === g) h = (b - r) / d + 2;
			else h = (r - g) / d + 4;
			h *= 60;
		}
		return { h: Math.round(h), s: Math.round(s * 100), l: Math.round(l * 100) };
	}

	function normalizeColor(input) {
		var value = String(input || "").trim().toLowerCase();
		var hexMatch = /^#?([0-9a-f]{3}|[0-9a-f]{6})$/.exec(value);
		if (!hexMatch) return null;
		var hex = "#" + hexMatch[1];
		return hex;
	}

	function insert(view, text) {
		var range = view.state.selection.main;
		view.dispatch({
			changes: { from: range.from, to: range.to, insert: text },
			selection: { anchor: range.from + text.length },
			scrollIntoView: true,
		});
	}

	xcoder.setPluginInit(PLUGIN_ID, function () {
		var select = xcoder.require("select");
		var prompt = xcoder.require("prompt");

		xcoder.addCommand({
			name: "color-insert:pick",
			description: "Pick a color (hex/rgb/hsl) and insert it",
			bindKey: "Ctrl-Alt-H",
			readOnly: false,
			exec: function (view) {
				if (!view || !view.state) return false;
				var items = PALETTE.map(function (hex) {
					return { value: hex, text: hex, hex: hex };
				});
				items.push({ value: "custom", text: "✏️ Outra cor (hex)…" });
				select("Color Picker", items, {})
					.then(function (choice) {
						if (!choice) return null;
						var hex = choice === "custom" ? prompt("Hex (#7b61ff)", "#7b61ff", "text", {}) : Promise.resolve(choice);
						return Promise.resolve(hex);
					})
					.then(function (hex) {
						if (!hex) return null;
						var normalized = normalizeColor(hex);
						if (!normalized) {
							toast("Cor inválida: " + hex);
							return null;
						}
						return select(
							"Formato",
							[
								{ value: "hex", text: "HEX  " + normalized },
								{ value: "rgb", text: "RGB" },
								{ value: "hsl", text: "HSL" },
							],
							{},
						).then(function (format) {
							if (!format) return null;
							var rgb = hexToRgb(normalized);
							var text = normalized;
							if (format === "rgb" && rgb) {
								text = "rgb(" + rgb.r + ", " + rgb.g + ", " + rgb.b + ")";
							} else if (format === "hsl" && rgb) {
								var hsl = rgbToHsl(rgb.r, rgb.g, rgb.b);
								text = "hsl(" + hsl.h + ", " + hsl.s + "%, " + hsl.l + "%)";
							}
							insert(view, text);
						});
					})
					.catch(function () { /* cancelled */ });
				return true;
			},
		});

		function toast(msg, ms) {
			xcoder.require("toast")(msg, ms || 3000);
		}

		xcoder.setPluginUnmount(PLUGIN_ID, function () {
			xcoder.removeCommand("color-insert:pick");
		});
	});
})();
