(function () {
	"use strict";
	var xcoder = window.xcoder;
	if (!xcoder || typeof xcoder.setPluginInit !== "function") return;

	var PLUGIN_ID = "xcoder.line-tools";

	function blockRange(view) {
		var state = view.state;
		var selection = state.selection.main;
		return {
			fromLine: state.doc.lineAt(selection.from),
			toLine: state.doc.lineAt(selection.to),
			selection: selection,
		};
	}

	function moveLines(view, direction) {
		if (!view || !view.state) return false;
		var state = view.state;
		var range = blockRange(view);
		var fromLine = range.fromLine;
		var toLine = range.toLine;
		var anchor = range.selection.anchor;
		var head = range.selection.head;

		if (direction < 0) {
			if (fromLine.from === 0) return false;
			var prevLine = state.doc.line(fromLine.number - 1);
			var block = state.sliceDoc(fromLine.from, toLine.to);
			var prev = state.sliceDoc(prevLine.from, prevLine.to);
			view.dispatch({
				changes: {
					from: prevLine.from,
					to: toLine.to,
					insert: block + "\n" + prev,
				},
				selection: {
					anchor: anchor - (prev.length + 1),
					head: head - (prev.length + 1),
				},
				scrollIntoView: true,
			});
			return true;
		}

		if (toLine.to === state.doc.length) return false;
		var nextLine = state.doc.line(toLine.number + 1);
		var blockText = state.sliceDoc(fromLine.from, toLine.to);
		var next = state.sliceDoc(nextLine.from, nextLine.to);
		view.dispatch({
			changes: {
				from: fromLine.from,
				to: nextLine.to,
				insert: next + "\n" + blockText,
			},
			selection: {
				anchor: anchor + (next.length + 1),
				head: head + (next.length + 1),
			},
			scrollIntoView: true,
		});
		return true;
	}

	xcoder.setPluginInit(PLUGIN_ID, function () {
		xcoder.addCommand({
			name: "line-tools:duplicate",
			description: "Duplicate the current line or selection",
			bindKey: "Ctrl-Shift-D",
			readOnly: false,
			exec: function (view) {
				if (!view || !view.state) return false;
				var state = view.state;
				var range = blockRange(view);
				var fromLine = range.fromLine;
				var toLine = range.toLine;
				var selection = range.selection;
				var block = state.sliceDoc(fromLine.from, toLine.to);
				var anchorOffset = selection.anchor - fromLine.from;
				var headOffset = selection.head - fromLine.from;
				var insertPos = toLine.to;
				view.dispatch({
					changes: { from: insertPos, insert: "\n" + block },
					selection: {
						anchor: insertPos + 1 + anchorOffset,
						head: insertPos + 1 + headOffset,
					},
					scrollIntoView: true,
				});
				return true;
			},
		});

		xcoder.addCommand({
			name: "line-tools:move-up",
			description: "Move current line or selection up",
			readOnly: false,
			exec: function (view) {
				return moveLines(view, -1);
			},
		});

		xcoder.addCommand({
			name: "line-tools:move-down",
			description: "Move current line or selection down",
			readOnly: false,
			exec: function (view) {
				return moveLines(view, 1);
			},
		});

		xcoder.setPluginUnmount(PLUGIN_ID, function () {
			var names = [
				"line-tools:duplicate",
				"line-tools:move-up",
				"line-tools:move-down",
			];
			for (var i = 0; i < names.length; i++) xcoder.removeCommand(names[i]);
		});
	});
})();
