# Line Tools

> Duplicate, move up and move down lines or blocks without cutting and pasting.

**Line Tools** adds three editing commands that every keyboard user misses on mobile: **duplicate** the current line or selected block (`Ctrl-Shift-D`), **move up** and **move down** the current line or block. Selections are preserved and moved together with the text, exactly like desktop editors.

## Usage
Place the cursor on a line (or select a block), open the command palette and search for *Line tools*. All commands also appear in the key bindings editor, so you can remap them freely.

## Português
**Ferramentas de linha**: duplica (`Ctrl-Shift-D`), move para cima e move para baixo a linha atual ou o bloco selecionado, preservando a seleção.

---

*Part of the [Xcoder plugin marketplace](https://github.com/carsaimz/xcoder-plugins). MIT licensed.*
