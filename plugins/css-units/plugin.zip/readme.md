# CSS Unit Converter

> Convert px ↔ rem ↔ em across the selection or document (root 16px).

**CSS Unit Converter** rewrites every length value in the selection — or the whole document — between `px`, `rem` and `em`. Decimal values are handled (`1.5rem`), results are rounded to three decimals and untouched units are left alone. Ideal when migrating a stylesheet to a root-relative scale.

## Usage
Select the rules to convert (or nothing for the whole file), run **CSS unit converter** (`Ctrl-Alt-P`) and pick the direction — e.g. `px → rem (root 16px)`.

## Português
**Conversor de unidades CSS**: converte px ↔ rem ↔ em na seleção ou no documento inteiro (raiz 16px), decimais incluídos. Atalho `Ctrl-Alt-P`.

---

*Part of the [Xcoder plugin marketplace](https://github.com/carsaimz/xcoder-plugins). MIT licensed.*
