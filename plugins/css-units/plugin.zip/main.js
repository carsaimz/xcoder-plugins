(function () {
	"use strict";
	var xcoder = window.xcoder;
	if (!xcoder || typeof xcoder.setPluginInit !== "function") return;

	var PLUGIN_ID = "xcoder.css-units";
	var ROOT_PX = 16;

	var OPTIONS = [
		["px-to-rem", "px → rem (root 16px)"],
		["rem-to-px", "rem → px (root 16px)"],
		["px-to-em", "px → em (context 16px)"],
		["em-to-px", "em → px (context 16px)"],
	];

	function round3(value) {
		return Math.round(value * 1000) / 1000;
	}

	/**
	 * Converts every `<number>unit` occurrence in the text.
	 * Uses a capture group so decimals like `1.5rem` are handled.
	 */
	function convertUnits(text, direction) {
		var unit = direction.indexOf("rem") >= 0 ? "rem" : "em";
		var from = direction.indexOf("px-to") === 0 ? "px" : unit;
		var to = from === "px" ? unit : "px";
		var factor = from === "px" ? 1 / ROOT_PX : ROOT_PX;
		var re = new RegExp("(-?\\d*\\.?\\d+)" + from + "\\b", "g");
		return text.replace(re, function (_match, number) {
			return round3(parseFloat(number) * factor) + to;
		});
	}

	xcoder.setPluginInit(PLUGIN_ID, function () {
		var select = xcoder.require("select");
		var toast = xcoder.require("toast");

		xcoder.addCommand({
			name: "css-units:convert",
			description: "Convert px ↔ rem ↔ em in the selection or document",
			bindKey: "Ctrl-Alt-P",
			readOnly: false,
			exec: function (view) {
				if (!view || !view.state) return false;
				var state = view.state;
				var selection = state.selection.main;
				var hasSelection = !!(selection && !selection.empty);
				var from = hasSelection ? selection.from : 0;
				var to = hasSelection ? selection.to : state.doc.length;
				var original = state.sliceDoc(from, to);
				if (!original) {
					toast("CSS units: nothing to convert", 2500);
					return true;
				}
				return select("CSS unit converter", OPTIONS)
					.then(function (choice) {
						if (!choice) return null;
						var converted = convertUnits(original, choice);
						if (converted === original) {
							toast("CSS units: no " + (choice.indexOf("px-to") === 0 ? "px" : choice.indexOf("rem") >= 0 ? "rem" : "em") + " values found", 2500);
							return null;
						}
						return converted;
					})
					.then(function (result) {
						if (result === null) return true;
						view.dispatch({
							changes: { from: from, to: to, insert: result },
							selection: { anchor: from, head: from + result.length },
						});
						toast("✓ converted", 2000);
						return true;
					});
			},
		});

		xcoder.setPluginUnmount(PLUGIN_ID, function () {
			xcoder.removeCommand("css-units:convert");
		});
	});
})();
