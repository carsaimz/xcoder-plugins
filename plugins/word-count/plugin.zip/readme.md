# Word Count

> Count words, characters and lines of the document or selection.

**Word Count** adds a single command that reports the number of words, characters (with and without spaces) and lines of the current document — or of the active selection, when there is one.

## Usage
Open the command palette and run **Word count: show words, characters and lines** (shortcut `Ctrl-Alt-W`). A toast appears with the statistics. Ideal for essays, README files and any text with a size limit.

## Português
**Contador de palavras**: um comando que mostra palavras, caracteres (com e sem espaços) e linhas do documento ou da seleção ativa. Atalho `Ctrl-Alt-W`.

---

*Part of the [Xcoder plugin marketplace](https://github.com/carsaimz/xcoder-plugins). MIT licensed.*
