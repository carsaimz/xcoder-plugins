(function () {
	"use strict";
	var xcoder = window.xcoder;
	if (!xcoder || typeof xcoder.setPluginInit !== "function") return;

	var PLUGIN_ID = "xcoder.word-count";

	function formatNumber(value) {
		return String(value).replace(/\B(?=(\d{3})+(?!\d))/g, ",");
	}

	xcoder.setPluginInit(PLUGIN_ID, function () {
		var toast = xcoder.require("toast");

		xcoder.addCommand({
			name: "word-count:show",
			description: "Word count: show words, characters and lines",
			bindKey: "Ctrl-Alt-W",
			readOnly: true,
			exec: function (view) {
				if (!view || !view.state) return false;
				var state = view.state;
				var selection = state.selection.main;
				var hasSelection = !!(selection && !selection.empty);
				var text = hasSelection
					? state.sliceDoc(selection.from, selection.to)
					: state.doc.toString();
				var words = (text.match(/[\p{L}\p{N}_'-]+/gu) || []).length;
				var chars = text.length;
				var charsNoSpace = text.replace(/\s/g, "").length;
				var lines = text.split("\n").length;
				var scope = hasSelection ? "Selection" : "Document";
				toast(
					scope +
						" - " +
						formatNumber(words) +
						" words, " +
						formatNumber(chars) +
						" chars (" +
						formatNumber(charsNoSpace) +
						" no spaces), " +
						formatNumber(lines) +
						" lines",
					4000,
				);
				return true;
			},
		});

		xcoder.setPluginUnmount(PLUGIN_ID, function () {
			xcoder.removeCommand("word-count:show");
		});
	});
})();
