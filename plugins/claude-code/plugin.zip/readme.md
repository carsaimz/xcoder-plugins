# Claude Code (XCoder)

Réplica funcional do fluxo do Claude Code (Anthropic) adaptada ao XCoder.

## Comandos

| Comando | Atalho | O que faz |
| --- | --- | --- |
| Claude Code: generate CLAUDE.md | Ctrl-Alt-5 | Escreve `CLAUDE.md` na raiz do projeto |
| Claude Code: plan prompt | Ctrl-Alt-4 | Seleção → prompt plan-first |
| Claude Code: commit message | Ctrl-Alt-0 | Mensagem de commit → clipboard |

Funciona offline; usa a área de transferência e o sistema de ficheiros do app.