(function () {
	"use strict";
	var xcoder = window.xcoder;
	if (!xcoder || typeof xcoder.setPluginInit !== "function") return;

	var PLUGIN_ID = "xcoder.html-skeleton";

	function toast(msg, ms) {
		xcoder.require("toast")(msg, ms || 3000);
	}

	function skeleton(lang, title) {
		return (
			'<!DOCTYPE html>\n<html lang="' + lang + '">\n<head>\n' +
			'\t<meta charset="UTF-8" />\n' +
			'\t<meta name="viewport" content="width=device-width, initial-scale=1.0" />\n' +
			"\t<title>" + title + "</title>\n" +
			"\t<style>\n" +
			"\t\t*, *::before, *::after { box-sizing: border-box; }\n" +
			"\t\tbody { margin: 0; font-family: system-ui, sans-serif; color: #1f2937; background: #ffffff; }\n" +
			"\t</style>\n" +
			"</head>\n<body>\n\n</body>\n</html>"
		);
	}

	xcoder.setPluginInit(PLUGIN_ID, function () {
		var select = xcoder.require("select");

		xcoder.addCommand({
			name: "html-skeleton:insert",
			description: "Insert a complete HTML5 page scaffold",
			bindKey: "Ctrl-Alt-O",
			readOnly: false,
			exec: function (view) {
				if (!view || !view.state) return false;
				select(
					"HTML Skeleton",
					[
						{ value: "pt", text: "Português (lang=pt)" },
						{ value: "en", text: "English (lang=en)" },
					],
					{},
				)
					.then(function (choice) {
						if (!choice) return null;
						var range = view.state.selection.main;
						view.dispatch({
							changes: {
								from: range.from,
								to: range.to,
								insert: skeleton(
									choice,
									choice === "pt" ? "A minha página" : "My page",
								),
							},
							scrollIntoView: true,
						});
						toast("✓ HTML5");
						return true;
					})
					.catch(function () { /* cancelled */ });
				return true;
			},
		});
	});

	xcoder.setPluginUnmount &&
		xcoder.setPluginUnmount(PLUGIN_ID, function () {});
})();
