# HTML Skeleton

> Insert a complete HTML5 page scaffold (charset, viewport, title, reset CSS).

**HTML Skeleton** inserts a ready-to-edit HTML5 document: doctype, `lang` attribute (pt/en), UTF-8 charset, responsive viewport meta, a `<title>` and a small reset CSS (border-box, clean margins, system font stack). Inspired by the classic 'HTML Page Generator' idea from Acode's catalog.

## Usage
Open an empty (or new) html file, run **HTML skeleton** (`Ctrl-Alt-O`) and choose the language. The scaffold replaces an empty selection or the whole document.

## Português
**Esqueleto HTML5**: insere um documento completo — doctype, charset, viewport, título e reset CSS. Atalho `Ctrl-Alt-O`.

---

*Part of the [Xcoder plugin marketplace](https://github.com/carsaimz/xcoder-plugins). MIT licensed.*
