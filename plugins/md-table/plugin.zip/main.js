(function () {
	"use strict";
	var xcoder = window.xcoder;
	if (!xcoder || typeof xcoder.setPluginInit !== "function") return;

	var PLUGIN_ID = "xcoder.md-table";

	/** Splits a table row into cells, respecting escaped pipes. */
	function splitRow(line) {
		var cells = [];
		var current = "";
		for (var i = 0; i < line.length; i++) {
			var char = line[i];
			if (char === "\\" && line[i + 1] === "|") {
				current += "|";
				i++;
				continue;
			}
			if (char === "|") {
				cells.push(current.trim());
				current = "";
				continue;
			}
			current += char;
		}
		cells.push(current.trim());
		return cells;
	}

	function isSeparator(line) {
		return /^\s*\|?\s*:?-{2,}:?\s*(\|\s*:?-{2,}:?\s*)+\|?\s*$/.test(line);
	}

	function pad(text, width, align) {
		var length = text.length;
		if (length >= width) return text;
		var missing = width - length;
		if (align === "right") return " ".repeat(missing) + text;
		if (align === "center") {
			var left = Math.floor(missing / 2);
			return " ".repeat(left) + text + " ".repeat(missing - left);
		}
		return text + " ".repeat(missing);
	}

	/** Reads the alignment row (`---`, `:---`, `:---:`, `---:`). */
	function alignmentOf(cells) {
		return cells.map(function (cell) {
			var left = cell[0] === ":";
			var right = cell[cell.length - 1] === ":";
			if (left && right) return "center";
			if (right) return "right";
			return "left";
		});
	}

	/** Formats contiguous markdown table lines with aligned columns. */
	function formatTables(text) {
		var lines = text.split(/\r?\n/);
		var out = [];
		var i = 0;
		while (i < lines.length) {
			var isTable = (lines[i].indexOf("|") >= 0 && i + 1 < lines.length && isSeparator(lines[i + 1]));
			if (!isTable) {
				out.push(lines[i]);
				i++;
				continue;
			}
			var start = i;
			while (i < lines.length && lines[i].indexOf("|") >= 0) i++;
			var block = lines.slice(start, i);
			var header = splitRow(block[0]);
			var aligns = alignmentOf(splitRow(block[1]));
			while (aligns.length < header.length) aligns.push("left");
			var widths = header.map(function (cell, index) {
				var width = cell.length;
				for (var row = 2; row < block.length; row++) {
					var cells = splitRow(block[row]);
					if (cells[index]) width = Math.max(width, cells[index].length);
				}
				return Math.max(width, 3);
			});
			function renderRow(cells, index) {
				var padded = cells.map(function (cell, cellIndex) {
					return pad(cell, widths[cellIndex] || 3, aligns[cellIndex] || "left");
				});
				return "| " + padded.join(" | ") + " |";
			}
			out.push(renderRow(header));
			var sep = widths.map(function (width, index) {
				var align = aligns[index] || "left";
				var dashes = "-".repeat(width);
				if (align === "center") return ":" + dashes + ":";
				if (align === "right") return dashes + ":";
				return dashes;
			});
			out.push("| " + sep.join(" | ") + " |");
			for (var row = 2; row < block.length; row++) {
				out.push(renderRow(splitRow(block[row])));
			}
		}
		return out.join("\n");
	}

	xcoder.setPluginInit(PLUGIN_ID, function () {
		var toast = xcoder.require("toast");

		xcoder.addCommand({
			name: "md-table:format",
			description: "Format and align markdown tables in the selection or document",
			bindKey: "Ctrl-Alt-F",
			readOnly: false,
			exec: function (view) {
				if (!view || !view.state) return false;
				var state = view.state;
				var selection = state.selection.main;
				var hasSelection = !!(selection && !selection.empty);
				var from = hasSelection ? selection.from : 0;
				var to = hasSelection ? selection.to : state.doc.length;
				var original = state.sliceDoc(from, to);
				if (original.indexOf("|") < 0) {
					toast("Markdown table: no tables found", 2500);
					return true;
				}
				var formatted = formatTables(original);
				if (formatted === original) {
					toast("Markdown table: already aligned", 2000);
					return true;
				}
				view.dispatch({
					changes: { from: from, to: to, insert: formatted },
					scrollIntoView: true,
				});
				toast("✓ table aligned", 2000);
				return true;
			},
		});

		xcoder.setPluginUnmount(PLUGIN_ID, function () {
			xcoder.removeCommand("md-table:format");
		});
	});
})();
