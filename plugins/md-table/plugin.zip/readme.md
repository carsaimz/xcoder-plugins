# Markdown Table Formatter

> Format and align markdown tables with padded columns and preserved alignments.

**Markdown Table Formatter** takes messy, hand-typed markdown tables and aligns every column to the widest cell. Alignment markers (`:---`, `:---:`, `---:`) are preserved, escaped pipes (`\|`) survive, and multiple tables in one pass are all formatted at once. Great for READMEs and documentation.

## Usage
Select the table (or nothing for the whole document) and run **Markdown table formatter** (`Ctrl-Alt-F`).

## Português
**Formatador de tabelas Markdown**: alinha colunas na célula mais larga, preservando alinhamentos e pipes escapados. Atalho `Ctrl-Alt-F`.

---

*Part of the [Xcoder plugin marketplace](https://github.com/carsaimz/xcoder-plugins). MIT licensed.*
