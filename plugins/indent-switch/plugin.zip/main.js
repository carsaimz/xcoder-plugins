(function () {
	"use strict";
	var xcoder = window.xcoder;
	if (!xcoder || typeof xcoder.setPluginInit !== "function") return;

	var PLUGIN_ID = "xcoder.indent-switch";

	function toast(msg, ms) {
		xcoder.require("toast")(msg, ms || 3000);
	}

	function detectIndent(text) {
		var tabCount = 0;
		var spaceRuns = [];
		var lines = text.split("\n");
		for (var i = 0; i < lines.length; i++) {
			var line = lines[i];
			// whitespace-only lines carry no indentation signal
			if (!line.trim()) continue;
			var tabs = /^\t+/.exec(line);
			if (tabs) {
				tabCount++;
				continue;
			}
			var spaces = /^( +)\S/.exec(line);
			if (spaces) spaceRuns.push(spaces[1].length);
		}
		// the SMALLEST indent unit is the classic heuristic for the width
		var width = 4;
		if (spaceRuns.length) {
			width = spaceRuns.reduce(function (a, b) {
				return Math.min(a, b);
			});
			if (width < 2) width = 2;
		}
		return { tabs: tabCount, spaces: spaceRuns.length, width: width };
	}

	function toSpaces(text, width) {
		return text.replace(/^\t+/gm, function (tabs) {
			return new Array(tabs.length * width + 1).join(" ");
		});
	}

	function toTabs(text, width) {
		return text.replace(/^( {2,})/gm, function (spaces) {
			var tabs = Math.floor(spaces.length / width);
			return new Array(tabs + 1).join("\t");
		});
	}

	xcoder.setPluginInit(PLUGIN_ID, function () {
		var select = xcoder.require("select");

		xcoder.addCommand({
			name: "indent-switch:convert",
			description: "Convert indentation: tabs to spaces or spaces to tabs",
			bindKey: "Ctrl-Alt-I",
			readOnly: false,
			exec: function (view) {
				if (!view || !view.state) return false;
				var doc = view.state.doc;
				var info = detectIndent(doc.toString());

				var options = [
					{ value: "s2t", text: "Espaços → tabulações" },
					{ value: "t2s", text: "Tabulações → espaços" },
				];
				if (info.width && info.width !== 4) {
					options.push({
						value: "s2t" + info.width,
						text: "Espaços (" + info.width + ") → tabulações",
					});
					options.push({
						value: "t2s" + info.width,
						text: "Tabulações → " + info.width + " espaços",
					});
				}

				select(
					"Indentação detectada: " +
						(info.tabs && !info.spaces
							? "tabulações"
							: info.width + " espaços"),
					options,
					{},
				)
					.then(function (choice) {
						if (!choice) return false;
						var full = doc.toString();
						var converted;
						if (choice === "s2t") converted = toTabs(full, info.width);
						else if (choice === "t2s") converted = toSpaces(full, info.width);
						else if (/^s2t/.test(choice)) converted = toTabs(full, Number(choice.slice(3)));
						else converted = toSpaces(full, Number(choice.slice(3)));

						var linesChanged = 0;
						var oldLines = full.split("\n");
						var newLines = converted.split("\n");
						for (var i = 0; i < oldLines.length; i++) {
							if (oldLines[i] !== newLines[i]) linesChanged++;
						}
						if (!linesChanged) {
							toast("Nada a converter");
							return true;
						}
						view.dispatch({
							changes: { from: 0, to: doc.length, insert: converted },
							scrollIntoView: false,
						});
						toast("✓ " + linesChanged + " linha(s) convertida(s)");
					})
					.catch(function () { /* cancelled */ });
				return true;
			},
		});

		xcoder.setPluginUnmount(PLUGIN_ID, function () {
			xcoder.removeCommand("indent-switch:convert");
		});
	});
})();
