# Indent Switch

> Convert the document between tabs and spaces (2, 4 or the detected width).

**Indent Switch** detects the dominant indentation style of the document (tabs vs. spaces and the space width) and converts the whole file in one command. Mixed indentation is a classic source of diff noise and Python errors — this fixes it in a tap.

## Usage
Open the command palette and run **Convert indentation** (`Ctrl-Alt-I`). The dialog shows what was detected and offers spaces→tabs or tabs→spaces conversions (2, 4 or the detected width). A toast reports how many lines changed.

## Português
**Alternar indentação**: detecta o estilo do documento e converte entre tabulações e espaços (2, 4 ou a largura detectada). Atalho `Ctrl-Alt-I`.

---

*Part of the [Xcoder plugin marketplace](https://github.com/carsaimz/xcoder-plugins). MIT licensed.*
