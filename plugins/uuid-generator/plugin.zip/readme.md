# UUID Generator

> Generate UUID v4, short ids and random hex ids straight into the editor.

**UUID Generator** creates identifiers with cryptographically strong randomness (Web Crypto when available) and inserts them at the cursor: UUID v4 in upper/lowercase, without dashes, 12/16-char short ids (alphanumeric) and 16-digit hex ids. Perfect for test fixtures, database seeds, request ids and mock data.

## Usage
Open the command palette and run **UUID Generator** (`Ctrl-Alt-U`), pick the format — done. **Quick UUID** inserts a lowercase v4 instantly without any dialog.

## Português
**Gerador de UUID**: cria e insere UUID v4 (maiúsculas/minúsculas, sem traços), short ids e ids hex na posição do cursor, com aleatoriedade criptográfica. Atalho `Ctrl-Alt-U`.

---

*Part of the [Xcoder plugin marketplace](https://github.com/carsaimz/xcoder-plugins). MIT licensed.*
