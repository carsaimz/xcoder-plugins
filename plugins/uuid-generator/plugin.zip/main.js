(function () {
	"use strict";
	var xcoder = window.xcoder;
	if (!xcoder || typeof xcoder.setPluginInit !== "function") return;

	var PLUGIN_ID = "xcoder.uuid-generator";

	function toast(msg, ms) {
		xcoder.require("toast")(msg, ms || 3000);
	}

	function uuidV4() {
		if (typeof crypto !== "undefined" && crypto.randomUUID) {
			return crypto.randomUUID();
		}
		if (typeof crypto !== "undefined" && crypto.getRandomValues) {
			var bytes = new Uint8Array(16);
			crypto.getRandomValues(bytes);
			bytes[6] = (bytes[6] & 0x0f) | 0x40;
			bytes[8] = (bytes[8] & 0x3f) | 0x80;
			var hex = [];
			for (var i = 0; i < 16; i++) {
				hex.push((bytes[i] + 0x100).toString(16).slice(1));
			}
			return (
				hex.slice(0, 4).join("") + "-" +
				hex.slice(4, 6).join("") + "-" +
				hex.slice(6, 8).join("") + "-" +
				hex.slice(8, 10).join("") + "-" +
				hex.slice(10, 16).join("")
			);
		}
		// last resort (weak): timestamp + random math
		return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(
			/[xy]/g,
			function (c) {
				var r = (Math.random() * 16) | 0;
				var v = c === "x" ? r : (r & 0x3) | 0x8;
				return v.toString(16);
			},
		);
	}

	function shortId(length) {
		var alphabet = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
		var out = "";
		var bytes = new Uint8Array(length || 12);
		if (typeof crypto !== "undefined" && crypto.getRandomValues) {
			crypto.getRandomValues(bytes);
			for (var i = 0; i < bytes.length; i++) out += alphabet[bytes[i] % alphabet.length];
		} else {
			for (var j = 0; j < (length || 12); j++) {
				out += alphabet[Math.floor(Math.random() * alphabet.length)];
			}
		}
		return out;
	}

	function randomHex(digits) {
		var bytes = new Uint8Array(Math.ceil((digits || 16) / 2));
		if (typeof crypto !== "undefined" && crypto.getRandomValues) {
			crypto.getRandomValues(bytes);
		} else {
			for (var i = 0; i < bytes.length; i++) bytes[i] = Math.floor(Math.random() * 256);
		}
		var hex = "";
		for (var j = 0; j < bytes.length; j++) hex += (bytes[j] + 0x100).toString(16).slice(1);
		return hex.slice(0, digits || 16);
	}

	function insert(view, text) {
		var range = view.state.selection.main;
		view.dispatch({
			changes: { from: range.from, to: range.to, insert: text },
			selection: { anchor: range.from + text.length },
			scrollIntoView: true,
		});
	}

	xcoder.setPluginInit(PLUGIN_ID, function () {
		var select = xcoder.require("select");

		xcoder.addCommand({
			name: "uuid-generator:insert",
			description: "Generate and insert a UUID / short id / hex id",
			bindKey: "Ctrl-Alt-U",
			readOnly: false,
			exec: function (view) {
				if (!view || !view.state) return false;
				select(
					"UUID Generator",
					[
						{ value: "uuid", text: "UUID v4 (36 chars)" },
						{ value: "uuid-upper", text: "UUID v4 (UPPERCASE)" },
						{ value: "uuid-no-dash", text: "UUID v4 (without dashes)" },
						{ value: "short", text: "Short id (12 chars)" },
						{ value: "short16", text: "Short id (16 chars)" },
						{ value: "hex", text: "Hex id (16 digits)" },
					],
					{},
				)
					.then(function (choice) {
						if (!choice) return false;
						var value;
						if (choice === "uuid-upper") value = uuidV4().toUpperCase();
						else if (choice === "uuid-no-dash") value = uuidV4().replace(/-/g, "");
						else if (choice === "short") value = shortId(12);
						else if (choice === "short16") value = shortId(16);
						else if (choice === "hex") value = randomHex(16);
						else value = uuidV4();
						insert(view, value);
						toast("✓ " + value.slice(0, 20) + (value.length > 20 ? "…" : ""));
					})
					.catch(function () { /* cancelled */ });
				return true;
			},
		});

		xcoder.addCommand({
			name: "uuid-generator:quick-uuid",
			description: "Insert a UUID v4 instantly (no dialog)",
			bindKey: "",
			readOnly: false,
			exec: function (view) {
				if (!view || !view.state) return false;
				insert(view, uuidV4());
				return true;
			},
		});

		xcoder.setPluginUnmount(PLUGIN_ID, function () {
			xcoder.removeCommand("uuid-generator:insert");
			xcoder.removeCommand("uuid-generator:quick-uuid");
		});
	});
})();
