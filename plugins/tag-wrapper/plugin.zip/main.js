(function () {
	"use strict";
	var xcoder = window.xcoder;
	if (!xcoder || typeof xcoder.setPluginInit !== "function") return;

	var PLUGIN_ID = "xcoder.tag-wrapper";

	function toast(msg, ms) {
		xcoder.require("toast")(msg, ms || 3000);
	}

	function expandToSelection(view) {
		var state = view.state;
		var range = state.selection.main;
		if (range && !range.empty) return { from: range.from, to: range.to };
		var word = state.wordAt(range.head);
		if (!word) {
			toast("Selecione o texto a envolver");
			return null;
		}
		return { from: word.from, to: word.to };
	}

	xcoder.setPluginInit(PLUGIN_ID, function () {
		var prompt = xcoder.require("prompt");

		xcoder.addCommand({
			name: "tag-wrapper:wrap",
			description: "Wrap the selection with an HTML tag",
			bindKey: "Ctrl-Alt-R",
			readOnly: false,
			exec: function (view) {
				if (!view || !view.state) return false;
				var target = expandToSelection(view);
				if (!target) return true;
				prompt('Tag (ex.: "div class=box")', "div", "text", {})
					.then(function (input) {
						if (!input) return null;
						var value = String(input).trim().replace(/^<|>$/g, "");
						if (!value) return null;
						var parts = value.split(/\s+/);
						var name = parts[0].replace(/[^a-zA-Z0-9_-]/g, "");
						if (!name) {
							toast("Nome de tag inválido");
							return null;
						}
						var attrs = parts.slice(1).join(" ");
						var open = attrs ? "<" + name + " " + attrs + ">" : "<" + name + ">";
						var text = view.state.sliceDoc(target.from, target.to);
						view.dispatch({
							changes: {
								from: target.from,
								to: target.to,
								insert: open + text + "</" + name + ">",
							},
							scrollIntoView: true,
						});
						toast("✓ <" + name + ">");
						return true;
					})
					.catch(function () { /* cancelled */ });
				return true;
			},
		});
	});

	xcoder.setPluginUnmount &&
		xcoder.setPluginUnmount(PLUGIN_ID, function () {});
})();
