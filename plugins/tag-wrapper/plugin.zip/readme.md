# Tag Wrapper

> Wrap the selection with any HTML tag (including attributes) in one command.

**Tag Wrapper** surrounds the current selection — or the word under the cursor — with any HTML tag you type, attributes included: `div class=box` becomes `<div class=box>selection</div>`. Typing tags by hand around existing content is one of the most repetitive editing tasks in HTML; this plugin removes it.

## Usage
Select the text, open the command palette and run **Tag wrapper** (`Ctrl-Alt-R`), then type the tag name (optionally followed by attributes). Cancel closes the dialog without touching the text.

## Português
**Envolver com tag**: envolve a seleção (ou a palavra sob o cursor) com qualquer tag HTML — atributos incluídos, ex.: `div class=box`. Atalho `Ctrl-Alt-R`.

---

*Part of the [Xcoder plugin marketplace](https://github.com/carsaimz/xcoder-plugins). MIT licensed.*
