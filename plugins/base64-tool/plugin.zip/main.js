(function () {
	"use strict";
	var xcoder = window.xcoder;
	if (!xcoder || typeof xcoder.setPluginInit !== "function") return;

	var PLUGIN_ID = "xcoder.base64-tool";

	function encodeBase64(text, urlSafe) {
		var bytes = new TextEncoder().encode(text);
		var binary = "";
		var chunk = 0x8000;
		for (var i = 0; i < bytes.length; i += chunk) {
			binary += String.fromCharCode.apply(null, bytes.subarray(i, i + chunk));
		}
		var encoded = btoa(binary);
		if (!urlSafe) return encoded;
		return encoded.replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
	}

	function decodeBase64(text) {
		var normalized = text.trim().replace(/-/g, "+").replace(/_/g, "/");
		var padded = normalized + "=".repeat((4 - (normalized.length % 4)) % 4);
		var binary = atob(padded);
		var bytes = new Uint8Array(binary.length);
		for (var i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
		return new TextDecoder().decode(bytes);
	}

	var OPTIONS = [
		["encode", "Base64 encode"],
		["decode", "Base64 decode"],
		["base64url", "Base64 encode (URL-safe)"],
		["url-encode", "URL encode (percent)"],
		["url-decode", "URL decode (percent)"],
	];

	xcoder.setPluginInit(PLUGIN_ID, function () {
		var select = xcoder.require("select");
		var toast = xcoder.require("toast");

		xcoder.addCommand({
			name: "base64-tool:convert",
			description: "Encode or decode Base64 / URL text",
			readOnly: false,
			exec: function (view) {
				if (!view || !view.state) return false;
				var state = view.state;
				var selection = state.selection.main;
				var hasSelection = !!(selection && !selection.empty);
				var from = hasSelection ? selection.from : 0;
				var to = hasSelection ? selection.to : state.doc.length;
				var original = state.sliceDoc(from, to);
				if (!original) {
					toast("Base64 tool: nothing to convert", 2500);
					return false;
				}
				return select("Base64 & URL tool", OPTIONS)
					.then(function (choice) {
						if (!choice) return null;
						try {
							switch (choice) {
								case "encode":
									return encodeBase64(original, false);
								case "base64url":
									return encodeBase64(original, true);
								case "decode":
									return decodeBase64(original);
								case "url-encode":
									return encodeURIComponent(original);
								case "url-decode":
									return decodeURIComponent(original);
								default:
									return null;
							}
						} catch (error) {
							toast("Base64 tool: invalid input", 2500);
							return null;
						}
					})
					.then(function (result) {
						if (result === null || result === original) return true;
						view.dispatch({
							changes: { from: from, to: to, insert: result },
							selection: { anchor: from, head: from + result.length },
						});
						return true;
					});
			},
		});

		xcoder.setPluginUnmount(PLUGIN_ID, function () {
			xcoder.removeCommand("base64-tool:convert");
		});
	});
})();
