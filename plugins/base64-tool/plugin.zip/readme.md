# Base64 & URL Tool

> Encode/decode Base64 (with full Unicode support) and percent-encoded URLs.

**Base64 & URL Tool** converts the current selection — or the whole document — between plain text and: Base64, URL-safe Base64, Base64 decoded back, percent-encoded URLs and decoded URLs. Unicode is handled correctly (accents, emoji, CJK), so Portuguese text survives every round-trip.

## Usage
Select the text to convert, open the command palette and run **Base64 & URL tool**. Invalid Base64 input shows a friendly toast instead of crashing.

## Português
**Ferramenta Base64 e URL**: codifica/decodifica Base64 (com suporte completo a Unicode) e URLs percent-encodings da seleção ou do documento inteiro.

---

*Part of the [Xcoder plugin marketplace](https://github.com/carsaimz/xcoder-plugins). MIT licensed.*
