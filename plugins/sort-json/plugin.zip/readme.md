# Sort JSON

> Sort JSON object keys recursively (A→Z or Z→A) while keeping arrays intact.

**Sort JSON** alphabetically sorts every object key of the selected JSON — or the whole document — recursively, producing a stable, diff-friendly output. Arrays keep their order (only their object items get their keys sorted). Invalid JSON shows a friendly toast instead of failing silently.

## Usage
Select the JSON (or nothing for the whole document), run **Sort JSON** (`Ctrl-Alt-D`) and choose A→Z or Z→A. Great before committing configs, translations and API fixtures.

## Português
**Ordenar JSON**: ordena recursivamente as chaves dos objetos (A→Z ou Z→A) mantendo a ordem dos arrays. Atalho `Ctrl-Alt-D`.

---

*Part of the [Xcoder plugin marketplace](https://github.com/carsaimz/xcoder-plugins). MIT licensed.*
