(function () {
	"use strict";
	var xcoder = window.xcoder;
	if (!xcoder || typeof xcoder.setPluginInit !== "function") return;

	var PLUGIN_ID = "xcoder.sort-json";

	function toast(msg, ms) {
		xcoder.require("toast")(msg, ms || 3000);
	}

	function targetText(view) {
		var state = view.state;
		var range = state.selection.main;
		var has = !!(range && !range.empty);
		return {
			text: has ? state.sliceDoc(range.from, range.to) : state.doc.toString(),
			from: has ? range.from : 0,
			to: has ? range.to : state.doc.length,
		};
	}

	function sortKeys(value, dir) {
		if (Array.isArray(value)) {
			return value.map(function (item) {
				return sortKeys(item, dir);
			});
		}
		if (value && typeof value === "object") {
			var keys = Object.keys(value).sort(function (a, b) {
				return a.localeCompare(b) * dir;
			});
			var out = {};
			for (var i = 0; i < keys.length; i++) {
				out[keys[i]] = sortKeys(value[keys[i]], dir);
			}
			return out;
		}
		return value;
	}

	xcoder.setPluginInit(PLUGIN_ID, function () {
		var select = xcoder.require("select");

		xcoder.addCommand({
			name: "sort-json:run",
			description: "Sort JSON object keys recursively (A→Z / Z→A)",
			bindKey: "Ctrl-Alt-D",
			readOnly: false,
			exec: function (view) {
				if (!view || !view.state) return false;
				select(
					"Sort JSON",
					[
						{ value: "1", text: "A → Z (recursivo)" },
						{ value: "-1", text: "Z → A (recursivo)" },
					],
					{},
				)
					.then(function (choice) {
						if (!choice) return null;
						var target = targetText(view);
						var parsed;
						try {
							parsed = JSON.parse(target.text);
						} catch (error) {
							toast("JSON inválido: " + String(error.message || error).slice(0, 80), 4500);
							return null;
						}
						var sorted = sortKeys(parsed, Number(choice));
						view.dispatch({
							changes: {
								from: target.from,
								to: target.to,
								insert: JSON.stringify(sorted, null, 2),
							},
							scrollIntoView: true,
						});
						toast("✓ Chaves ordenadas");
						return true;
					})
					.catch(function () { /* cancelled */ });
				return true;
			},
		});
	});

	xcoder.setPluginUnmount &&
		xcoder.setPluginUnmount(PLUGIN_ID, function () {});
})();
