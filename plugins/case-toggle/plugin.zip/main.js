(function () {
	"use strict";
	var xcoder = window.xcoder;
	if (!xcoder || typeof xcoder.setPluginInit !== "function") return;

	var PLUGIN_ID = "xcoder.case-toggle";

	function words(text) {
		return text
			.replace(/([a-z0-9])([A-Z])/g, "$1 $2")
			.split(/[^A-Za-z0-9]+/)
			.filter(Boolean);
	}

	function upper(s) {
		return s.toUpperCase();
	}

	function lower(s) {
		return s.toLowerCase();
	}

	function titleCase(s) {
		var w = words(s);
		if (!w.length) return s;
		return w
			.map(function (item) {
				return item.charAt(0).toUpperCase() + item.slice(1).toLowerCase();
			})
			.join(" ");
	}

	function sentence(s) {
		var w = words(s);
		if (!w.length) return s;
		return (
			w[0].charAt(0).toUpperCase() +
			w[0].slice(1).toLowerCase() +
			(w.length > 1 ? " " + w.slice(1).join(" ").toLowerCase() : "")
		);
	}

	function camel(s) {
		var w = words(s).map(function (item) {
			return item.toLowerCase();
		});
		if (!w.length) return s;
		return w[0] + w.slice(1)
			.map(function (item) {
				return item.charAt(0).toUpperCase() + item.slice(1);
			})
			.join("");
	}

	function snake(s) {
		var w = words(s).map(function (item) {
			return item.toLowerCase();
		});
		return w.length ? w.join("_") : s;
	}

	function kebab(s) {
		var w = words(s).map(function (item) {
			return item.toLowerCase();
		});
		return w.length ? w.join("-") : s;
	}

	function inverse(s) {
		return s.replace(/[A-Za-z]/g, function (c) {
			return c === c.toUpperCase() ? c.toLowerCase() : c.toUpperCase();
		});
	}

	var TRANSFORMS = {
		upper: { label: "UPPER CASE", fn: upper },
		lower: { label: "lower case", fn: lower },
		title: { label: "Title Case", fn: titleCase },
		sentence: { label: "Sentence case", fn: sentence },
		camel: { label: "camelCase", fn: camel },
		snake: { label: "snake_case", fn: snake },
		kebab: { label: "kebab-case", fn: kebab },
		inverse: { label: "iNVERSE cASE", fn: inverse },
	};

	var OPTIONS = Object.keys(TRANSFORMS).map(function (value) {
		return [value, TRANSFORMS[value].label];
	});

	function expandTarget(view) {
		var state = view.state;
		var selection = state.selection.main;
		if (selection && !selection.empty) {
			return { from: selection.from, to: selection.to };
		}
		var pos = selection ? selection.head : 0;
		var line = state.doc.lineAt(pos);
		var text = line.text;
		var start = pos - line.from;
		var end = start;
		function isWordChar(c) {
			return /[\p{L}\p{N}_]/u.test(c);
		}
		while (start > 0 && isWordChar(text.charAt(start - 1))) start--;
		while (end < text.length && isWordChar(text.charAt(end))) end++;
		if (start === end) return null;
		return { from: line.from + start, to: line.from + end };
	}

	xcoder.setPluginInit(PLUGIN_ID, function () {
		var select = xcoder.require("select");
		var toast = xcoder.require("toast");

		xcoder.addCommand({
			name: "case-toggle:convert",
			description: "Convert case of selection or word",
			bindKey: "Ctrl-Alt-C",
			readOnly: false,
			exec: function (view) {
				if (!view || !view.state) return false;
				var range = expandTarget(view);
				if (!range) {
					toast("Case converter: nothing selected", 2500);
					return false;
				}
				var original = view.state.sliceDoc(range.from, range.to);
				return select("Case converter", OPTIONS).then(function (choice) {
					if (!choice || !TRANSFORMS[choice]) return false;
					var converted = TRANSFORMS[choice].fn(original);
					if (converted === original) return true;
					view.dispatch({
						changes: { from: range.from, to: range.to, insert: converted },
						selection: {
							anchor: range.from,
							head: range.from + converted.length,
						},
					});
					return true;
				});
			},
		});

		xcoder.setPluginUnmount(PLUGIN_ID, function () {
			xcoder.removeCommand("case-toggle:convert");
		});
	});
})();
