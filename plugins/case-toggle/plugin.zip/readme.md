# Case Converter

> Convert the selection or word to UPPER, lower, Title, camelCase, snake_case and more.

**Case Converter** transforms the current selection — or the word under the cursor — between eight case styles: `UPPER CASE`, `lower case`, `Title Case`, `Sentence case`, `camelCase`, `snake_case`, `kebab-case` and `iNVERSE cASE`.

## Usage
Select some text (or just place the cursor on a word), open the command palette and run **Case converter** (`Ctrl-Alt-C`), then pick the target style. Great for constants, CSS class names and variable renaming without retyping.

## Português
**Conversor de maiúsculas**: transforma a seleção (ou a palavra sob o cursor) entre oito estilos — MAIÚSCULAS, minúsculas, Título, Sentença, camelCase, snake_case, kebab-case e invertido. Atalho `Ctrl-Alt-C`.

---

*Part of the [Xcoder plugin marketplace](https://github.com/carsaimz/xcoder-plugins). MIT licensed.*
