# Emoji Picker

> Browse a curated emoji set in six categories and insert it at the cursor.

**Emoji Picker** brings a lightweight emoji browser into the editor: six curated categories (smileys, gestures, status symbols, tech, nature & food and objects) with the emojis that actually matter for documentation, commit messages and UI copy. No heavy emoji database — a hand-picked set that loads instantly.

## Usage
Open the command palette and run **Emoji Picker** (`Ctrl-Alt-E`), choose a category, then tap the emoji to insert it. Works everywhere the editor accepts text.

## Português
**Seletor de emojis**: escolha entre seis categorias curadas (carinhas, gestos, status, tecnologia, natureza e objetos) e insira o emoji no cursor. Atalho `Ctrl-Alt-E`.

---

*Part of the [Xcoder plugin marketplace](https://github.com/carsaimz/xcoder-plugins). MIT licensed.*
