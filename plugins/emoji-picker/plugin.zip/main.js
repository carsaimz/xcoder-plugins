(function () {
	"use strict";
	var xcoder = window.xcoder;
	if (!xcoder || typeof xcoder.setPluginInit !== "function") return;

	var PLUGIN_ID = "xcoder.emoji-picker";

	/** Curated set — the emojis that matter for docs, commits and UI copy. */
	var GROUPS = [
		{
			value: "smileys",
			text: "😀 Smileys & pessoas",
			emojis: "😀 😃 😄 😁 😆 😅 🤣 😂 🙂 😉 😊 😇 🥰 😍 🤩 😘 😗 😋 😛 😜 🤪 🤨 🧐 🤓 😎 🥳 😏 😒 😞 😔 😟 😕 🙁 😣 😖 😫 😩 🥺 😢 😭 😤 😠 😡 🤯 😳 🥵 🥶 😱 😨 😰 🤗 🤔 🤭 🤫 🤥 😶 😐 😑 😬 🙄 😯 😲 🥱 😴 🤤 😪 😵 🤐 🥴 🤢 🤮 🤧 😷 🤒 🤕 🤑 🤠 👻 💀 ☠️ 👽 🤖 🎃 😺 😸 😹 😻 🙀 😿".split(" "),
		},
		{
			value: "gestures",
			text: "👍 Gestos",
			emojis: "👍 👎 👌 ✌️ 🤞 🤟 🤘 🤙 👈 👉 👆 👇 ☝️ 👏 🙌 🤝 🙏 💪 🦾 ✍️ 💅 🤳 🫡 🫶 👋 🤚 🖐️ ✋ 🖖 👊 ✊ 🤛 🤜 🫰 🫵".split(" "),
		},
		{
			value: "status",
			text: "✅ Status e símbolos",
			emojis: "✅ ❌ ⚠️ 🚫 ⛔ ❗ ❓ 💡 🔥 ✨ ⭐ 🌟 💫 ⚡ ☄️ 💥 🔔 🎯 🏁 🚀 🎉 🎊 🏆 🥇 🥈 🥉 🏅 🎖️ 💯 ✳️ ❇️ ♻️ 🔱 ⚙️ 🧩 🔒 🔓 🔑 🛡️ ⚔️ 💎 🪄 🧪 🛠️ 📌 📍".split(" "),
		},
		{
			value: "dev",
			text: "💻 Tecnologia",
			emojis: "💻 🖥️ ⌨️ 🖱️ 🖲️ 💾 💿 📀 🧮 📱 ☎️ 📞 📟 📠 🔌 🪫 🔋 📡 🛰️ 🌐 🌍 🕸️ 🧭 ⏱️ ⏰ 📱 📲 💻 🖨️ 🧠 👀 🦾 🤖 🧑‍💻 👨‍💻 👩‍💻 🫥".split(" "),
		},
		{
			value: "nature",
			text: "🌿 Natureza e comida",
			emojis: "🌱 🌿 ☘️ 🍀 🌵 🌴 🌲 🌳 🌸 🌺 🌻 🌼 🌷 🌹 🥀 🌾 🌊 🌊 🏔️ ⛰️ 🌋 🏜️ 🏝️ 🌅 🌄 🌇 🌆 🌃 🌌 🌠 ☀️ 🌤️ ⛅ 🌧️ ⛈️ 🌩️ ❄️ ☃️ ⛄ 🌬️ 💨 🍎 🍌 🍇 🍓 🫐 🍒 🍑 🥭 🍍 🥝 🍉 🍋 🍊 🍞 🧀 🍔 🍟 🍕 🌭 🌮 🌯 🍣 🍱 🍜 🍝 🍤 🍦 🎂 🍰 ☕ 🍵 🧉 🍺".split(" "),
		},
		{
			value: "objects",
			text: "📦 Objetos e escrever",
			emojis: "📚 📖 📕 📗 📘 📙 📔 📒 📃 📄 📑 📰 🗞️ 📋 📁 📂 🗂️ 🗃️ 🗄️ 🗑️ 📝 ✏️ 🖊️ 🖋️ 🖌️ 🖍️ 📏 📐 ✂️ 🗜️ 🔖 🏷️ 💼 🎒 👝 👞 🥾 👟 🧵 🧶 🪡 🪢 ⌚ 💡 🔦 🏮 📸 📷 🎥 🎬 🎞️ 🎤 🎧 🎺 🎸 🎻 🥁 🎹 🎲 ♟️ 🎮 🎯 🎳 🎰 🧸".split(" "),
		},
	];

	function insert(view, text) {
		var range = view.state.selection.main;
		view.dispatch({
			changes: { from: range.from, to: range.to, insert: text },
			selection: { anchor: range.from + text.length },
			scrollIntoView: true,
		});
	}

	xcoder.setPluginInit(PLUGIN_ID, function () {
		var select = xcoder.require("select");

		function pickEmoji(view) {
			if (!view || !view.state) return false;
			select("Emoji Picker", GROUPS, {})
				.then(function (groupValue) {
					if (!groupValue) return null;
					var group = GROUPS.filter(function (g) { return g.value === groupValue; })[0];
					if (!group) return null;
					var items = group.emojis.map(function (emoji) {
						return { value: emoji, text: emoji };
					});
					return select(group.text, items, {});
				})
				.then(function (emoji) {
					if (emoji) insert(view, emoji);
				})
				.catch(function () { /* cancelled */ });
			return true;
		}

		xcoder.addCommand({
			name: "emoji-picker:insert",
			description: "Pick and insert an emoji",
			bindKey: "Ctrl-Alt-E",
			readOnly: false,
			exec: pickEmoji,
		});

		xcoder.setPluginUnmount(PLUGIN_ID, function () {
			xcoder.removeCommand("emoji-picker:insert");
		});
	});
})();
