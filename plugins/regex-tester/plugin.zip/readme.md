# Regex Tester

> Test regular expressions against text and optionally replace the matches.

**Regex Tester** runs a regular expression against the current selection — or sample text you type — and shows every match with its capture groups. From the same dialog you can jump straight to a replace-all pass with `$1` group references.

## Usage
Run **Regex tester** (`Ctrl-Alt-V`), fill in the pattern and flags, then choose *Show matches* or *Replace matches*. Invalid patterns and catastrophic empty matches are handled safely.

## Português
**Testador de regex**: testa expressões regulares sobre a seleção (ou texto informado), mostra todos os matches com grupos e permite substituir usando `$1`. Atalho `Ctrl-Alt-V`.

---

*Part of the [Xcoder plugin marketplace](https://github.com/carsaimz/xcoder-plugins). MIT licensed.*
