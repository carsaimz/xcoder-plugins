(function () {
	"use strict";
	var xcoder = window.xcoder;
	if (!xcoder || typeof xcoder.setPluginInit !== "function") return;

	var PLUGIN_ID = "xcoder.regex-tester";

	function safeRegex(pattern, flags) {
		try {
			return new RegExp(pattern, flags || "g");
		} catch (e) {
			return null;
		}
	}

	function describeMatches(sample, regex) {
		var count = 0;
		var lines = [];
		var re = new RegExp(regex.source, regex.flags.indexOf("g") >= 0 ? regex.flags : regex.flags + "g");
		var match;
		while ((match = re.exec(sample)) !== null) {
			count++;
			if (lines.length < 10) {
				var groups = match.slice(1).filter(function (g) {
					return g !== undefined;
				});
				lines.push("#" + count + "  " + JSON.stringify(match[0]) + (groups.length ? "  groups: " + JSON.stringify(groups) : ""));
			}
			if (match[0] === "") {
				re.lastIndex++;
			}
			if (count > 1000) break;
		}
		return { count: count, lines: lines };
	}

	xcoder.setPluginInit(PLUGIN_ID, function () {
		var toast = xcoder.require("toast");
		var prompt = xcoder.require("prompt");
		var select = xcoder.require("select");
		var alert = xcoder.require("alert");

		xcoder.addCommand({
			name: "regex-tester:test",
			description: "Test a regular expression against the selection or sample text",
			bindKey: "Ctrl-Alt-V",
			readOnly: true,
			exec: function (view) {
				if (!view || !view.state) return false;
				var state = view.state;
				var selection = state.selection.main;
				var hasSelection = !!(selection && !selection.empty);
				var sample = hasSelection ? state.sliceDoc(selection.from, selection.to) : "";
				var rangeFrom = hasSelection ? selection.from : 0;
				var rangeTo = hasSelection ? selection.to : state.doc.length;

				var pattern = null;
				return (hasSelection && sample
					? Promise.resolve(sample)
					: prompt("Sample text to test against", sample || "hello world 123").then(function (value) {
						if (!value) return null;
						sample = value;
						return value;
					})
				)
					.then(function (text) {
						if (text === null) return null;
						return prompt("Regular expression (e.g. \\w+)", "\\w+").then(function (value) {
							if (!value) return null;
							pattern = value;
							return pattern;
						});
					})
					.then(function (value) {
						if (value === null) return null;
						return prompt("Flags (g, i, m…)", "g").then(function (flags) {
							var re = safeRegex(pattern, flags || "g");
							if (!re) {
								toast("Regex tester: invalid pattern or flags", 3000);
								return null;
							}
							var result = describeMatches(sample, re);
							if (!result.count) {
								toast("Regex tester: no matches", 2500);
								return null;
							}
							var summary = result.count + " match(es):\n" + result.lines.join("\n");
							if (result.count > 10) summary += "\n… and " + (result.count - 10) + " more";
							return select("Regex tester — " + result.count + " matches", [
								["done", "Show matches only"],
								["replace", "Replace matches…"],
							]).then(function (choice) {
								if (!choice) return null;
								if (choice === "done") {
									alert("Regex matches", summary);
									return null;
								}
								return prompt("Replacement (use $1 for groups)", "").then(function (replacement) {
									if (replacement === null) return null;
									var replaced = sample.replace(re, replacement);
									view.dispatch({
										changes: { from: rangeFrom, to: rangeTo, insert: replaced },
										selection: { anchor: rangeFrom, head: rangeFrom + replaced.length },
									});
									toast("✓ replaced " + result.count + " match(es)", 2200);
									return null;
								});
							});
						});
					})
					.catch(function () {
						return null;
					})
					.then(function () {
						return true;
					});
			},
		});

		xcoder.setPluginUnmount(PLUGIN_ID, function () {
			xcoder.removeCommand("regex-tester:test");
		});
	});
})();
