(function () {
	"use strict";
	var xcoder = window.xcoder;
	if (!xcoder || typeof xcoder.setPluginInit !== "function") return;

	var PLUGIN_ID = "xcoder.quote-converter";

	function toast(msg, ms) {
		xcoder.require("toast")(msg, ms || 3000);
	}

	function targetRange(view) {
		var state = view.state;
		var range = state.selection.main;
		if (range && !range.empty) return { from: range.from, to: range.to };
		var word = state.wordAt(range.head);
		if (!word) return null;
		return { from: word.from, to: word.to };
	}

	function convert(text, mode) {
		if (mode === "remove") {
			return text.replace(/^['"`]|['"`]$/g, "");
		}
		var target = mode === "single" ? "'" : '"';
		var other = mode === "single" ? '"' : "'";
		var out = "";
		var quote = null;
		for (var i = 0; i < text.length; i++) {
			var ch = text[i];
			if (ch === "\\") {
				out += ch + (text[i + 1] || "");
				i++;
				continue;
			}
			if (quote) {
				if (ch === quote) {
					quote = null;
					out += target;
				} else if (ch === target) {
					out += "\\" + ch;
				} else {
					out += ch;
				}
			} else if (ch === other) {
				quote = ch;
				out += target;
			} else {
				out += ch;
			}
		}
		return out;
	}

	xcoder.setPluginInit(PLUGIN_ID, function () {
		var select = xcoder.require("select");

		xcoder.addCommand({
			name: "quote-converter:run",
			description: "Convert quotes in the selection or word (' \" `)",
			bindKey: "Ctrl-Alt-Q",
			readOnly: false,
			exec: function (view) {
				if (!view || !view.state) return false;
				select(
					"Quote Converter",
					[
						{ value: "double", text: '→ Aspas duplas  "texto"' },
						{ value: "single", text: "→ Aspas simples  'texto'" },
						{ value: "remove", text: "→ Remover aspas externas" },
					],
					{},
				)
					.then(function (choice) {
						if (!choice) return null;
						var range = targetRange(view);
						if (!range) {
							toast("Nada para converter aqui");
							return null;
						}
						var text = view.state.sliceDoc(range.from, range.to);
						view.dispatch({
							changes: {
								from: range.from,
								to: range.to,
								insert: convert(text, choice),
							},
							scrollIntoView: true,
						});
						return true;
					})
					.catch(function () { /* cancelled */ });
				return true;
			},
		});
	});

	xcoder.setPluginUnmount &&
		xcoder.setPluginUnmount(PLUGIN_ID, function () {});
})();
