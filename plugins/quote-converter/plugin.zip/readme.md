# Quote Converter

> Swap single/double quotes (or strip them) on the selection or word, with escaping.

**Quote Converter** converts the quotes around or inside the current selection — or the word under the cursor: single → double, double → single, or remove the outer quotes entirely. Inner quotes of the opposite kind are escaped automatically and backslash sequences are preserved, so JavaScript strings survive the round-trip.

## Usage
Select a string (or place the cursor on it), open the command palette and run **Quote converter** (`Ctrl-Alt-Q`), then pick the target style. Inspired by the classic Acode plugin of the same name, rebuilt for the Xcoder API.

## Português
**Conversor de aspas**: troca aspas simples/duplas (ou remove as externas) na seleção ou palavra, com escape automático. Atalho `Ctrl-Alt-Q`.

---

*Part of the [Xcoder plugin marketplace](https://github.com/carsaimz/xcoder-plugins). MIT licensed.*
