(function () {
	"use strict";
	var xcoder = window.xcoder;
	if (!xcoder || typeof xcoder.setPluginInit !== "function") return;

	var PLUGIN_ID = "xcoder.remove-duplicates";

	function toast(msg, ms) {
		xcoder.require("toast")(msg, ms || 3000);
	}

	function dedupe(text, mode, trim) {
		var lines = text.split("\n");
		var seen = {};
		var last = "";
		var out = [];
		var removed = 0;
		for (var i = 0; i < lines.length; i++) {
			var key = trim ? lines[i].trim() : lines[i];
			if (mode === "consecutive") {
				if (i > 0 && key === last) {
					removed++;
					continue;
				}
				last = key;
				out.push(lines[i]);
			} else {
				// key normalization for comparison only (case-insensitive option off)
				if (key in seen) {
					removed++;
					continue;
				}
				seen[key] = true;
				out.push(lines[i]);
			}
		}
		return { text: out.join("\n"), removed: removed };
	}

	xcoder.setPluginInit(PLUGIN_ID, function () {
		var select = xcoder.require("select");

		xcoder.addCommand({
			name: "remove-duplicates:run",
			description: "Remove duplicated lines (selection or document)",
			bindKey: "Ctrl-Alt-B",
			readOnly: false,
			exec: function (view) {
				if (!view || !view.state) return false;
				select(
					"Remover duplicadas",
					[
						{ value: "all", text: "Todas as duplicadas (mantém a 1ª)" },
						{ value: "consecutive", text: "Apenas linhas repetidas em sequência" },
						{ value: "all-trim", text: "Todas (ignora espaços das pontas)" },
					],
					{},
				)
					.then(function (choice) {
						if (!choice) return false;
						var state = view.state;
						var range = state.selection.main;
						var scoped = !!(range && !range.empty);
						var from = scoped ? range.from : 0;
						var to = scoped ? range.to : state.doc.length;
						var text = state.sliceDoc(from, to);

						var result = dedupe(
							text,
							choice === "consecutive" ? "consecutive" : "all",
							choice === "all-trim",
						);
						if (!result.removed) {
							toast("Nenhuma linha duplicada encontrada");
							return true;
						}
						view.dispatch({
							changes: { from: from, to: to, insert: result.text },
							scrollIntoView: true,
						});
						toast("✓ " + result.removed + " linha(s) removida(s)");
					})
					.catch(function () { /* cancelled */ });
				return true;
			},
		});

		xcoder.setPluginUnmount(PLUGIN_ID, function () {
			xcoder.removeCommand("remove-duplicates:run");
		});
	});
})();
