# Remove Duplicates

> Remove duplicated lines from the selection or document, keeping the first occurrence.

**Remove Duplicates** cleans lists, logs and generated data: it removes every repeated line (keeping the first), only consecutive repeats, or repeats compared after trimming whitespace. Works on the selection or the whole document and reports how many lines were removed.

## Usage
Select the text (or use the whole file), open the command palette and run **Remove duplicated lines** (`Ctrl-Alt-B`), then pick the mode. Pair it with *Sort Lines* for tidy lists.

## Português
**Remover duplicadas**: remove linhas repetidas da seleção ou do documento (mantém a primeira), com modo só-sequenciais e comparação ignorando espaços. Atalho `Ctrl-Alt-B`.

---

*Part of the [Xcoder plugin marketplace](https://github.com/carsaimz/xcoder-plugins). MIT licensed.*
