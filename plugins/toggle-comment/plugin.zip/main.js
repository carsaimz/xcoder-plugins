(function () {
	"use strict";
	var xcoder = window.xcoder;
	if (!xcoder || typeof xcoder.setPluginInit !== "function") return;

	var PLUGIN_ID = "xcoder.toggle-comment";

	/** Comment tokens by file extension (defaults to //). */
	var TOKENS = {
		js: ["//", ""], jsx: ["//", ""], ts: ["//", ""], tsx: ["//", ""],
		java: ["//", ""], kt: ["//", ""], kotlin: ["//", ""], swift: ["//", ""],
		c: ["//", ""], h: ["//", ""], cpp: ["//", ""], hpp: ["//", ""],
		cs: ["//", ""], go: ["//", ""], rs: ["//", ""], rust: ["//", ""],
		php: ["//", ""], dart: ["//", ""], scala: ["//", ""], groovy: ["//", ""],
		ino: ["//", ""], jsonc: ["//", ""], json5: ["//", ""],
		py: ["#", ""], python: ["#", ""], rb: ["#", ""], ruby: ["#", ""],
		sh: ["#", ""], bash: ["#", ""], zsh: ["#", ""], yml: ["#", ""],
		yaml: ["#", ""], toml: ["#", ""], ini: ["#", ""], conf: ["#", ""],
		r: ["#", ""], tf: ["#", ""], dockerfile: ["#", ""], env: ["#", ""],
		css: ["/* ", "*/"], scss: ["//", ""], sass: ["//", ""], less: ["//", ""],
		html: ["<!-- ", "-->"], xml: ["<!-- ", "-->"], svg: ["<!-- ", "-->"],
		md: ["<!-- ", "-->"], markdown: ["<!-- ", "-->"],
		vue: ["//", ""], svelte: ["//", ""],
		sql: ["--", ""], lua: ["--", ""], hs: ["--", ""],
	};

	function tokensFor() {
		var name = "";
		try {
			var file = window.editorManager && window.editorManager.activeFile;
			name = String((file && file.filename) || "");
		} catch (e) { /* ignore */ }
		var ext = name.split(".").pop().toLowerCase() || "";
		return TOKENS[ext] || ["//", ""];
	}

	/** true when every non-empty line in the range already starts with the token */
	function isCommented(lines, open) {
		var commented = 0;
		var nonEmpty = 0;
		for (var i = 0; i < lines.length; i++) {
			var line = lines[i];
			if (!line.trim()) continue;
			nonEmpty++;
			if (line.trim().indexOf(open) === 0) commented++;
		}
		return nonEmpty > 0 && commented === nonEmpty;
	}

	function toggle(view) {
		if (!view || !view.state) return false;
		var state = view.state;
		var range = state.selection.main;
		var fromLine = state.doc.lineAt(range.from);
		var toLine = state.doc.lineAt(range.to);
		var tokens = tokensFor();
		var open = tokens[0];
		var close = tokens[1];

		var lines = [];
		for (var n = fromLine.number; n <= toLine.number; n++) {
			lines.push(state.doc.line(n).text);
		}

		var changes = [];
		var minIndent = Infinity;

		if (isCommented(lines, open)) {
			for (var u = fromLine.number; u <= toLine.number; u++) {
				var line = state.doc.line(u);
				var idx = line.text.indexOf(open);
				if (idx === -1) continue;
				var end = idx + open.length;
				// swallow the padding space we add when commenting
				if (!close && line.text[end] === " ") end += 1;
				if (close) {
					var closeIdx = line.text.lastIndexOf(close);
					if (closeIdx > end) {
						// " ... */" — also swallow the space before the closer
						var closeFrom = closeIdx;
						if (line.text[closeIdx - 1] === " ") closeFrom -= 1;
						changes.push({
							from: line.from + closeFrom,
							to: line.from + closeIdx + close.length,
							insert: "",
						});
					}
				}
				changes.push({ from: line.from + idx, to: line.from + end, insert: "" });
			}
		} else {
			for (var c = 0; c < lines.length; c++) {
				if (lines[c].trim()) {
					minIndent = Math.min(minIndent, lines[c].match(/^\s*/)[0].length);
				}
			}
			if (!isFinite(minIndent)) minIndent = 0;
			for (var l = fromLine.number; l <= toLine.number; l++) {
				var docLine = state.doc.line(l);
				if (!docLine.text.trim()) continue;
				changes.push({
					from: docLine.from + minIndent,
					to: docLine.from + minIndent,
					insert: open + (close ? "" : " "),
				});
				if (close) {
					changes.push({ from: docLine.to, to: docLine.to, insert: " " + close });
				}
			}
		}

		if (!changes.length) return false;
		view.dispatch({ changes: changes, scrollIntoView: true });
		return true;
	}

	xcoder.setPluginInit(PLUGIN_ID, function () {
		xcoder.addCommand({
			name: "toggle-comment:toggle",
			description: "Toggle comment on the current line or selection",
			bindKey: "Ctrl-/",
			readOnly: false,
			exec: toggle,
		});

		xcoder.setPluginUnmount(PLUGIN_ID, function () {
			xcoder.removeCommand("toggle-comment:toggle");
		});
	});
})();
