# Toggle Comment

> Comment or uncomment the current line/selection with the right token for the file type.

**Toggle Comment** comments or uncomments the current line or the whole selection with one command (`Ctrl-/`). The comment token matches the file you are editing: `//` for JavaScript, TypeScript, Java, Go, Rust…; `#` for Python, Ruby, YAML, Shell; `--` for SQL and Lua; `/* */` for CSS; `<!-- -->` for HTML and Markdown. Multi-line selections are commented at the shared indentation level, and running it again removes the comments cleanly.

## Usage
Place the cursor on a line (or select a block) and run **Toggle comment** from the command palette (`Ctrl-/`). Inspired by the classic desktop editors' Ctrl-/ behaviour.

## Português
**Toggle Comment**: comenta/descomenta a linha atual ou a seleção com o token certo para o tipo de arquivo (`//`, `#`, `--`, `/* */`, `<!-- -->`). Atalho `Ctrl-/`.

---

*Part of the [Xcoder plugin marketplace](https://github.com/carsaimz/xcoder-plugins). MIT licensed.*
