# Blank Lines

> Remove or collapse empty lines, trim trailing spaces and rejoin wrapped lines.

**Blank Lines** cleans up whitespace noise in one command: remove ALL empty lines, collapse them down to a single one, trim trailing spaces per line, or rejoin lines that were wrapped mid-sentence (paragraph mode keeps blank-line breaks). Works on the selection or the whole document.

## Usage
Select the messy region (or nothing for the whole file), run **Blank lines** (`Ctrl-Alt-A`) and pick the cleaning mode.

## Português
**Linhas vazias**: remove/colapsa linhas vazias, corta espaços no fim das linhas e junta linhas quebradas. Atalho `Ctrl-Alt-A`.

---

*Part of the [Xcoder plugin marketplace](https://github.com/carsaimz/xcoder-plugins). MIT licensed.*
