(function () {
	"use strict";
	var xcoder = window.xcoder;
	if (!xcoder || typeof xcoder.setPluginInit !== "function") return;

	var PLUGIN_ID = "xcoder.blank-lines";

	function toast(msg, ms) {
		xcoder.require("toast")(msg, ms || 3000);
	}

	function targetText(view) {
		var state = view.state;
		var range = state.selection.main;
		var has = !!(range && !range.empty);
		return {
			text: has ? state.sliceDoc(range.from, range.to) : state.doc.toString(),
			from: has ? range.from : 0,
			to: has ? range.to : state.doc.length,
		};
	}

	function clean(text, mode) {
		if (mode === "remove") {
			return text
				.split("\n")
				.filter(function (line) { return line.trim().length > 0; })
				.join("\n");
		}
		if (mode === "collapse") {
			return text
				.split("\n")
				.reduce(function (acc, line) {
					var isEmpty = line.trim().length === 0;
					if (isEmpty && acc.length && acc[acc.length - 1] === "") return acc;
					acc.push(line);
					return acc;
				}, [])
				.join("\n");
		}
		if (mode === "trim") {
			return text
				.split("\n")
				.map(function (line) { return line.replace(/\s+$/, ""); })
				.join("\n");
		}
		// join: single newlines become spaces, blank lines stay as breaks
		return text
			.split("\n")
			.reduce(function (acc, line) {
				if (line.trim().length === 0) {
					acc.push("");
				} else if (acc.length && acc[acc.length - 1] !== "") {
					acc[acc.length - 1] += " " + line.trim();
				} else {
					acc.push(line.trim());
				}
				return acc;
			}, [])
			.join("\n");
	}

	var ACTIONS = [
		{ value: "remove", text: "Remover TODAS as linhas vazias" },
		{ value: "collapse", text: "Colapsar linhas vazias (manter 1)" },
		{ value: "trim", text: "Cortar espaços no fim das linhas" },
		{ value: "join", text: "Juntar linhas quebradas (parágrafos)" },
	];

	xcoder.setPluginInit(PLUGIN_ID, function () {
		var select = xcoder.require("select");

		xcoder.addCommand({
			name: "blank-lines:run",
			description: "Clean empty lines, trailing spaces or wrapped lines",
			bindKey: "Ctrl-Alt-A",
			readOnly: false,
			exec: function (view) {
				if (!view || !view.state) return false;
				select("Blank Lines", ACTIONS, {})
					.then(function (choice) {
						if (!choice) return null;
						var target = targetText(view);
						view.dispatch({
							changes: {
								from: target.from,
								to: target.to,
								insert: clean(target.text, choice),
							},
							scrollIntoView: true,
						});
						toast("✓ Limpo");
						return true;
					})
					.catch(function () { /* cancelled */ });
				return true;
			},
		});
	});

	xcoder.setPluginUnmount &&
		xcoder.setPluginUnmount(PLUGIN_ID, function () {});
})();
