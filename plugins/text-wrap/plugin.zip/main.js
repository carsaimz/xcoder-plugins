(function () {
	"use strict";
	var xcoder = window.xcoder;
	if (!xcoder || typeof xcoder.setPluginInit !== "function") return;

	var PLUGIN_ID = "xcoder.text-wrap";

	/** Greedy word wrap that preserves leading indentation. */
	function wrapLine(line, width) {
		if (line.length <= width) return [line];
		var indent = (line.match(/^[ \t]*/) || [""])[0];
		var words = line.slice(indent.length).split(/\s+/).filter(Boolean);
		if (!words.length) return [line];
		var lines = [];
		var current = indent;
		for (var i = 0; i < words.length; i++) {
			var candidate = current === indent ? current + words[i] : current + " " + words[i];
			if (current !== indent && candidate.length > width) {
				lines.push(current);
				current = indent + words[i];
			} else {
				current = candidate;
			}
		}
		if (current.trim()) lines.push(current);
		return lines;
	}

	function wrapText(text, width) {
		return text
			.split("\n")
			.map(function (line) {
				return wrapLine(line, width).join("\n");
			})
			.join("\n");
	}

	xcoder.setPluginInit(PLUGIN_ID, function () {
		var toast = xcoder.require("toast");
		var prompt = xcoder.require("prompt");

		xcoder.addCommand({
			name: "text-wrap:wrap",
			description: "Wrap the selection or document at a column width (default 80)",
			readOnly: false,
			exec: function (view) {
				if (!view || !view.state) return false;
				var state = view.state;
				var selection = state.selection.main;
				var hasSelection = !!(selection && !selection.empty);
				var from = hasSelection ? selection.from : 0;
				var to = hasSelection ? selection.to : state.doc.length;
				var original = state.sliceDoc(from, to);
				if (!original) {
					toast("Text wrap: nothing to wrap", 2500);
					return true;
				}
				return prompt("Wrap at column width", "80").then(function (value) {
					var width = parseInt(value, 10);
					if (!Number.isFinite(width) || width < 10 || width > 500) {
						toast("Text wrap: width must be between 10 and 500", 3000);
						return true;
					}
					var wrapped = wrapText(original, width);
					if (wrapped === original) {
						toast("Text wrap: nothing to change", 2000);
						return true;
					}
					view.dispatch({
						changes: { from: from, to: to, insert: wrapped },
						selection: { anchor: from, head: from + wrapped.length },
					});
					toast("✓ wrapped at " + width + " columns", 2000);
					return true;
				});
			},
		});

		xcoder.setPluginUnmount(PLUGIN_ID, function () {
			xcoder.removeCommand("text-wrap:wrap");
		});
	});
})();
