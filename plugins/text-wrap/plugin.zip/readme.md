# Text Wrap

> Reflow the selection or document at a column width (default 80).

**Text Wrap** reflows paragraphs to a maximum column width using a greedy word-wrap algorithm. Leading indentation is preserved for every produced line, so wrapped Markdown lists and indented prose keep their structure.

## Usage
Select the text (or run on the whole document) and execute **Text wrap: wrap**, then type the width (10–500, default 80). Great for README files, commit messages and plain-text email.

## Português
**Text Wrap**: refluí o texto numa largura máxima de coluna (padrão 80), preservando a indentação. Ideal para README, mensagens de commit e prosa em texto puro.

---

*Part of the [Xcoder plugin marketplace](https://github.com/carsaimz/xcoder-plugins). MIT licensed.*
